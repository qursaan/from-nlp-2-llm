"""Level 2: reply or ask, ELIZA-style (Book, Chapter 2).

Sanad never invents a procedure. It routes when it knows the intent and the
slots it needs; otherwise it reflects the message back and asks.
"""
import re

LEVEL = 2
STUDENT = ("reflect", "reply")

REFLECT = {"i": "you", "me": "you", "my": "your", "am": "are", "i'm": "you're",
           "ana": "enta", "3ayez": "3ayez"}
NEEDS_COURSE = ("assessment", "registration")
OFFICE = {"access": "IT support", "assessment": "the examinations office",
          "registration": "the registrar", "fees": "the finance office",
          "other": "student affairs"}


def reflect(text):
    """Swap first-person words for second-person ones, word by word."""
    return " ".join(REFLECT.get(w, w) for w in re.findall(r"[\w']+", text.lower()))


def reply(intent, course=None, text=""):
    """One reply: a question when something is missing, else a routing message."""
    if intent is None:
        return f"You said: {reflect(text)}. Is this about access, an exam, registration, fees, or something else?"
    if intent in NEEDS_COURSE and course is None:
        return "Which course is this about? Please give its code, for example NLP101."
    where = f" for {course}" if course else ""
    return f"I am sending your request{where} to {OFFICE[intent]}."
