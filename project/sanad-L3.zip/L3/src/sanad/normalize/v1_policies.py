"""Normaliser v1: declared regular-expression policies (Level 2; Book, Chapter 2).

Each function is one written policy. The order of normalize() is part of the
policy: elongation is collapsed after the letters are unified.
"""
import re

LEVEL = 2
STUDENT = ("remove_marks", "unify_letters", "ascii_digits", "collapse_elongation",
           "normalize")

MARKS = re.compile(r"[ً-ْٰـ]")      # harakat, dagger alef, tatweel
ALEF = re.compile(r"[آأإٱ]")         # آ أ إ ٱ
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫", "01234567890123456789.")
ELONGATION = re.compile(r"(\w)\1{2,}")                   # three or more of one letter


def remove_marks(text):
    """P1-P2: delete short-vowel marks, dagger alef, and tatweel; never a letter."""
    return MARKS.sub("", text)


def unify_letters(text):
    """P3-P4: map alef variants to ا, ى to ي, and ة to ه."""
    return ALEF.sub("ا", text).replace("ى", "ي").replace("ة", "ه")


def ascii_digits(text):
    """P5: Arabic-Indic and Persian digits to 0-9; the Arabic decimal mark ٫ to '.'."""
    return text.translate(DIGITS)


def collapse_elongation(text):
    """P6: a letter repeated three or more times becomes one ('gamiiiil' -> 'gamil').

    Known loss: a laugh 'hhhh' becomes 'h', and 'www' becomes 'w'.
    """
    return ELONGATION.sub(r"\1", text)


def normalize(text):
    """P1-P7 in order; P7 lower-cases Latin letters."""
    return collapse_elongation(ascii_digits(unify_letters(remove_marks(text)))).lower()
