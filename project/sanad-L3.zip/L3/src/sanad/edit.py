"""Level 3: minimum edit distance (Book, Chapter 3)."""
LEVEL = 3
STUDENT = ("levenshtein",)


def levenshtein(a, b, sub_cost=1):
    """Insertions and deletions cost 1, a substitution costs sub_cost."""
    raise NotImplementedError("Level 3: levenshtein")
