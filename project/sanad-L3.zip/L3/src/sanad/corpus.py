"""Level 3: describe a split before trusting its counts (Book, Chapter 3).

Every count depends on the tokenization policy, so these functions take the
prepared token lists (prep = tokenizer after normaliser), never raw text.
A type seen exactly once is a hapax legomenon.
"""
from collections import Counter

LEVEL = 3
STUDENT = ("counts", "describe")


def counts(token_lists):
    """{"tokens": N, "types": V, "hapax": types seen once, "ttr": V/N or None}."""
    raise NotImplementedError("Level 3: counts")


def describe(prep, tickets):
    """{variety: counts(...)} for each variety in tickets, plus "all" for the whole split."""
    raise NotImplementedError("Level 3: describe")
