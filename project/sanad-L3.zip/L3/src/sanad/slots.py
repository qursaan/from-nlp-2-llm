"""Level 2: extract the course code and the amount from a ticket (Book, Chapter 2).

Run on normalised text, so Arabic-Indic digits are already 0-9.
"""
import re

LEVEL = 2
STUDENT = ("course", "amount")

COURSE = re.compile(r"\b([a-z]{2,4})\s?-?([0-9]{3})\b", re.I)
AMOUNT = re.compile(r"(?<![\w.,])([0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:\.([0-9]{1,2}))?(?![\w,]|\.[0-9])")


def course(text):
    """First course code as letters+digits, upper case ('cs 214' -> 'CS214'), or None."""
    m = COURSE.search(text)
    return (m.group(1) + m.group(2)).upper() if m else None


def amount(text):
    """First amount without thousands commas ('1,250' -> '1250', '150.50' -> '150.50').

    A number glued to letters is not an amount: not the 101 of 'NLP101', and not
    the Arabizi letters of '3ayez' or 'a5osh'. Known failure: any other
    free-standing number, such as a room, is taken as one.
    """
    m = AMOUNT.search(text)
    if not m:
        return None
    whole = m.group(1).replace(",", "")
    return f"{whole}.{m.group(2)}" if m.group(2) else whole
