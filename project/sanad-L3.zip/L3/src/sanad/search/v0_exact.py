"""Search v0: rank passages by exact token overlap with the question (Level 1)."""
from sanad.data import passage_text

LEVEL = 1
STUDENT = ("Search.fit", "Search.score", "Search.search")


class Search:
    def __init__(self, prep, passages):
        self.prep = prep
        self.passages = passages
        self.tokens = {}

    def fit(self):
        """Prepare each passage once: id -> set of its tokens."""
        self.tokens = {p["id"]: set(self.prep(passage_text(p))) for p in self.passages}
        return self

    def score(self, query_tokens, pid):
        """Number of distinct query tokens that occur in passage pid."""
        return len(set(query_tokens) & self.tokens[pid])

    def search(self, query, k=3):
        """Ids of the k best passages with a positive score; ties by id."""
        q = self.prep(query)
        scored = [(self.score(q, pid), pid) for pid in self.tokens]
        scored = [(s, pid) for s, pid in scored if s > 0]
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [pid for _, pid in scored[:k]]
