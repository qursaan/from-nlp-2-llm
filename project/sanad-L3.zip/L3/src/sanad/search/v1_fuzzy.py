"""Search v1: exact overlap, but tolerate small spelling differences (Level 3; Book, Chapter 3).

A query token matches a passage token when their edit distance is at most
max_edits(token). Short tokens must match exactly: 'fee' and 'see' are one edit
apart and mean different things.
"""
from sanad.edit import levenshtein
from sanad.search.v0_exact import Search as Exact

LEVEL = 3
STUDENT = ("max_edits", "Search.matches", "Search.score")


def max_edits(token):
    """0 edits for tokens of up to 3 characters, 1 up to 6, then 2."""
    raise NotImplementedError("Level 3: max_edits")


class Search(Exact):
    def matches(self, q, pid):
        """True if some token of passage pid is within max_edits(q) of q."""
        raise NotImplementedError("Level 3: matches")

    def score(self, query_tokens, pid):
        """Number of distinct query tokens that match passage pid."""
        raise NotImplementedError("Level 3: score")
