"""Router v1: keyword patterns per intent (Level 2; Book, Chapter 2).

Patterns run on the prepared text (normalised tokens joined by spaces). Each
intent scores the number of its patterns that match; the highest score wins,
ties go to the earlier intent in RULES, and no match returns None so that the
clarifier can ask.
"""
import re

LEVEL = 2
STUDENT = ("Router.fit", "Router.scores", "Router.predict")

# Written from the 75 training tickets only; dev and test were not read.
RULES = {
    "access": [r"log ?in|password|portal|wi-?fi|account|locked|course page",
               r"البوابه|كلمه المرور|الباسورد|الدخول|ادخل|بشبكه|صفحه",
               r"a5osh|password|portal|saf7et"],
    "assessment": [r"exam|midterm|quiz|result|submission",
                   r"امتحان|الامتحان|الميدترم|الواجب|تسليم|غبت|تغيبت",
                   r"emte7an|midterm|daragti|at2alem|ghebt"],
    "registration": [r"regist|enrol|add |drop|prerequisite|schedule",
                     r"التسجيل|اسجل|اضافه|اضيف|احذف|اشيل|المتطلب",
                     r"tasgeel|asagel|adif|ashil"],
    "fees": [r"fee|pay|paid|refund|instalment|receipt|tuition|egp",
             r"المصروفات|المصاريف|ادفع|دفعت|الايصال|استرد|هسترد|جنيه|فلوس|خصم",
             r"masareef|adfa3|dafa3t|e2sal|a2asat|geneh"],
    "other": [r"cafeteria|library|parking|borrow",
              r"الكافتيريا|المكتبه|تصريح|استعاره",
              r"cafeteria|maktaba|karneh"],
}


class Router:
    def __init__(self, prep):
        self.prep = prep
        self.patterns = {}

    def fit(self, tickets):
        """Compile RULES; the training tickets are for your own checking, not learning."""
        self.patterns = {i: [re.compile(p) for p in ps] for i, ps in RULES.items()}
        return self

    def scores(self, text):
        """{intent: number of its patterns found in the prepared text}."""
        joined = " ".join(self.prep(text))
        return {i: sum(bool(p.search(joined)) for p in ps) for i, ps in self.patterns.items()}

    def predict(self, text):
        """Best-scoring intent; ties go to the earlier intent; None if nothing matched."""
        best, label = 0, None
        for intent, s in self.scores(text).items():
            if s > best:
                best, label = s, intent
        return label
