"""Level 3: describe the training tickets before trusting their counts."""
import pytest


def test_counts():
    pytest.skip('hidden test: graded by the instructor')


def test_describe_train_by_variety():
    pytest.skip('hidden test: graded by the instructor')


def test_counts_depend_on_the_normaliser():
    pytest.skip('hidden test: graded by the instructor')
