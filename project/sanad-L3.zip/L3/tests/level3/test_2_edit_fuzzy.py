"""Level 3: edit distance, and fuzzy search replaces exact search."""
import pytest


def test_levenshtein():
    pytest.skip('hidden test: graded by the instructor')


def test_max_edits():
    pytest.skip('hidden test: graded by the instructor')


def test_fuzzy_tolerates_a_typo():
    pytest.skip('hidden test: graded by the instructor')


def test_fuzzy_mrr_on_dev():
    pytest.skip('hidden test: graded by the instructor')
