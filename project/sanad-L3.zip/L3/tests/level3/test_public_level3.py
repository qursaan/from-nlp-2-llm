"""Level 3, public checkpoint checks: these ship to students unhidden.

Every expected value here is already printed in the book or the Lab Manual
(book Chapter 3, Lab Manual level 3), so nothing graded is revealed. The
graded tests in the other test_*.py files stay hidden until marking.

    python -m pytest tests/level3/test_public_level3.py -k c1   # checkpoint 1
"""
from sanad.corpus import counts
from sanad.edit import levenshtein

FEE_REQUEST = "3ayez adfa3 el fees bta3et MATH205 250 EGP"     # Lab Manual, level 2


def test_c1_counts():
    c = counts(["pay the fee and the late fee today".split()])   # book Chapter 3, quiz 1
    assert (c["tokens"], c["types"], c["hapax"]) == (8, 6, 4)


def test_c2_edit_distance():
    assert levenshtein("exma", "exam") == 2                          # book Example 3.4
    assert levenshtein("ktb", "mktbh") == 2                          # book Example 3.5


def test_c3_fuzzy_search(pipeline_v1):
    assert pipeline_v1.search("v1_fuzzy").search(FEE_REQUEST)[0] == "F11"
    # Typo tolerance (Lab Manual, checkpoint 3): exact search finds nothing for
    # "pasword", while fuzzy search must rank F01 (Reset your portal password) first.
    assert pipeline_v1.search("v0_exact").search("pasword") == []
    assert pipeline_v1.search("v1_fuzzy").search("pasword")[0] == "F01"
