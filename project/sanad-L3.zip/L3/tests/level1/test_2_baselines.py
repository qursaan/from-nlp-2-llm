"""Level 1: Router v0 and Search v0 on the dev split."""
import pytest

from sanad import data, evaluate as ev


def test_majority_router(pipeline_v0):
    router = pipeline_v0.router("v0_majority")
    assert router.label == "access"            # five intents tie at 15; alphabetical
    assert router.predict("Where is the cafeteria?") == "access"
    rep = ev.router_report(router, data.tickets("dev"))
    assert rep["accuracy"] == pytest.approx(0.20)
    assert rep["margin95"] == pytest.approx(0.179, abs=5e-4)


def test_exact_search(pipeline_v0):
    search = pipeline_v0.search("v0_exact")
    assert search.search("forgot my portal password")[0] == "F01"
    assert search.search("nothing here matches xyz") == []
    rep = ev.search_report(search, data.tickets("dev"))
    assert rep["mrr"] == pytest.approx(0.567, abs=5e-4)
    assert rep["by_variety"]["msa"] > rep["by_variety"]["arabizi"]


def test_test_split_is_closed():
    with pytest.raises(PermissionError):
        data.tickets("test")
