"""Level 1: the harness reproduces the book's Chapter 1 numbers (and the Chapter 5 averages it supplies)."""
import pytest

from sanad import evaluate as ev

LABELS = ("access", "assessment", "registration", "other")
# The ten tickets of the book's four-intent matrix (rows: reference).
GOLD = ["access"] * 4 + ["assessment"] * 3 + ["registration"] * 2 + ["other"]
PRED = ["access", "access", "assessment", "registration",
        "assessment", "assessment", "assessment", "registration", "registration", "access"]


def test_accuracy():
    assert ev.accuracy(GOLD, PRED) == pytest.approx(0.7)


def test_confusion_rows_are_reference():
    m = ev.confusion(LABELS, GOLD, PRED)
    assert [m["access"][c] for c in LABELS] == [2, 1, 1, 0]
    assert m["other"]["access"] == 1 and m["other"][None] == 0


def test_per_class_keeps_undefined_precision():
    pc = ev.per_class(LABELS, GOLD, PRED)
    assert pc["access"] == pytest.approx((2 / 3, 0.5))
    assert pc["assessment"] == pytest.approx((0.75, 1.0))
    assert pc["other"] == (None, 0.0)          # never predicted: 0/0 is undefined


def test_macro_conventions_and_micro():
    prec = [p for p, _ in ev.per_class(LABELS, GOLD, PRED).values()]
    assert ev.macro(prec, "exclude") == pytest.approx(0.694, abs=5e-4)
    assert ev.macro(prec, "zero") == pytest.approx(0.521, abs=5e-4)
    assert ev.micro(LABELS, GOLD, PRED) == pytest.approx((0.7, 0.7))


def test_declined_predictions_are_misses_not_false_alarms():
    pred = PRED[:-1] + [None]
    assert ev.accuracy(GOLD, pred) == pytest.approx(0.7)
    p, r = ev.micro(LABELS, GOLD, pred)
    assert (p, r) == pytest.approx((7 / 9, 0.7))
    assert ev.confusion(LABELS, GOLD, pred)["other"][None] == 1


def test_f_beta():
    p, r = 0.8, 2 / 3
    assert ev.f_beta(p, r) == pytest.approx(8 / 11)
    assert ev.f_beta(p, r, 2) == pytest.approx(20 / 29)
    assert ev.f_beta(p, r, 0.5) == pytest.approx(10 / 13)
    assert ev.f_beta(None, 0.5) is None
    assert ev.f_beta(0.0, 0.0) == 0.0


def test_majority_and_margin():
    assert ev.majority_baseline(["b", "a", "b", "a", "c"]) == "a"   # tie: alphabetical
    assert ev.margin95(0.7, 10) == pytest.approx(0.29, abs=0.005)


def test_ranking_measures():
    ranked = ["d1", "d2", "d3", "d4", "d5"]
    relevant = {"d2", "d3", "d5"}
    assert [ev.precision_at_k(ranked, relevant, k) for k in (1, 3, 5)] == \
        pytest.approx([0, 2 / 3, 3 / 5])
    assert ev.reciprocal_rank(ranked, relevant) == 0.5
    assert ev.precision_at_k(["d2"], relevant, 3) == pytest.approx(1 / 3)
    assert ev.reciprocal_rank([], relevant) == 0.0
