"""Level 2: the declared normalisation policies."""
from sanad.normalize import v1_policies as nz


def test_marks_and_tatweel():
    assert nz.remove_marks("مُدَرِّسـة") == "مدرسة"


def test_letters():
    assert nz.unify_letters("إضافة أخرى") == "اضافه اخري"


def test_digits():
    assert nz.ascii_digits("دفعت ١٢٥٠ و١٥٠٫٥٠") == "دفعت 1250 و150.50"


def test_elongation():
    assert nz.collapse_elongation("gamiiiil!!!") == "gamil!!!"      # letters only
    assert nz.collapse_elongation("cool") == "cool"            # two letters stay


def test_order_and_case():
    assert nz.normalize("Gamiiiil NLP101 جمييييل") == "gamil nlp101 جميل"
