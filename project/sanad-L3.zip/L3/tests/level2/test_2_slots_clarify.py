"""Level 2: slot extraction and the clarifier."""
import pytest

from sanad import clarify, slots
from sanad.normalize.v1_policies import normalize


@pytest.mark.parametrize("text,course", [
    ("The course page for NLP101 is not showing", "NLP101"),
    ("i want to drop cs 214", "CS214"),
    ("سجلت مقرر CS214 ولا أرى صفحته", "CS214"),
    ("How do I connect to the campus Wi-Fi?", None),
])
def test_course(text, course):
    assert slots.course(normalize(text)) == course


@pytest.mark.parametrize("text,amount", [
    ("I paid 1,250 EGP but no receipt appears", "1250"),
    ("Why was I charged 150.50 EGP twice?", "150.50"),
    ("خصم مني ١٥٠٫٥٠ جنيها مرتين", "150.50"),
    ("The course page for NLP101 is not showing", None),
    ("3ayez adfa3 150 geneh", "150"),          # Arabizi digits are letters here
])
def test_amount(text, amount):
    assert slots.amount(normalize(text)) == amount


@pytest.mark.xfail(strict=True, reason="known failure: a free-standing room number looks like an amount")
def test_room_number_is_not_an_amount():
    assert slots.amount("the exam is in room 214") is None


def test_clarifier():
    assert clarify.reflect("I want my grade") == "you want your grade"
    assert "Which course" in clarify.reply("registration", None)
    assert clarify.reply("registration", "AI301").endswith("to the registrar.")
    assert clarify.reply(None, text="ana mish fahem").startswith("You said: enta mish fahem.")
