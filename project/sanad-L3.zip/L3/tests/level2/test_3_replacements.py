"""Level 2: the rule router replaces the v0 majority router."""
import pytest

from sanad import data, evaluate as ev


def test_rules_cover_the_training_tickets(pipeline_v1):
    router = pipeline_v1.router("v1_rules")
    train = data.tickets("train")
    acc = ev.accuracy([t["intent"] for t in train], [router.predict(t["text"]) for t in train])
    assert acc >= 0.9, "write rules for every intent from the training tickets"


def test_rules_decline_and_break_ties(pipeline_v1):
    router = pipeline_v1.router("v1_rules")
    assert router.predict("hello there") is None
    # 'account' (access) and 'quiz' (assessment) both match; access comes first.
    assert router.predict("Locked out of my account before the quiz!") == "access"


def test_rules_beat_the_baseline_on_dev(pipeline_v1):
    dev = data.tickets("dev")
    base = ev.router_report(pipeline_v1.router("v0_majority"), dev)["accuracy"]
    rules = ev.router_report(pipeline_v1.router("v1_rules"), dev)["accuracy"]
    assert rules > base
