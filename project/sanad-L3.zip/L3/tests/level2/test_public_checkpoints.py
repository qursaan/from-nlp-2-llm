"""Level 2, public checkpoint checks: these ship to students unhidden.

Every expected value here is already printed in the book or the Lab Manual
(Figures L2.1 and L2.2, book Chapter 2), so nothing graded is revealed. The
graded tests in the other test_*.py files stay hidden until marking.

    python -m pytest tests/level2/test_public_checkpoints.py -k c1   # checkpoint 1
"""
from sanad import clarify, slots
from sanad.normalize.v1_policies import collapse_elongation, normalize

FEE_REQUEST = "3ayez adfa3 el fees bta3et MATH205 250 EGP"     # Figure L2.2


def test_c1_normalise():
    assert normalize(FEE_REQUEST) == "3ayez adfa3 el fees bta3et math205 250 egp"
    assert collapse_elongation("gamiiiil") == "gamil"                # book Section 2.1.5


def test_c2_slots_and_reply():
    text = normalize(FEE_REQUEST)
    assert slots.course(text) == "MATH205"
    assert slots.amount(text) == "250"
    assert "MATH205" in clarify.reply("fees", "MATH205", FEE_REQUEST)


def test_c3_routing(pipeline_v1):
    router = pipeline_v1.router("v1_rules")
    assert router.predict("3ayez asagel NLP101 bokra") == "registration"   # Figure L2.1
    assert router.predict("I lost my student ID card") is None
    assert router.predict(FEE_REQUEST) == "fees"
