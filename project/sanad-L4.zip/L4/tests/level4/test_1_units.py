"""Level 4: NFC, a declared tokenization policy, and BPE learned from training text."""
import pytest


def test_nfc_before_the_policies():
    pytest.skip('hidden test: graded by the instructor')


def test_policy_tokens():
    pytest.skip('hidden test: graded by the instructor')


def test_policy_known_cost():
    pytest.skip('hidden test: graded by the instructor')


def test_merge():
    pytest.skip('hidden test: graded by the instructor')


def test_bpe_learns_from_training_text():
    pytest.skip('hidden test: graded by the instructor')


def test_bpe_round_trip():
    pytest.skip('hidden test: graded by the instructor')
