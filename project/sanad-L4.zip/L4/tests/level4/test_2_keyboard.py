"""Level 4: the frequency keyboard and the unknown-token rate."""
import pytest


def test_frequency_keyboard():
    pytest.skip('hidden test: graded by the instructor')


def test_keyboard_report():
    pytest.skip('hidden test: graded by the instructor')


def test_unknown_rate():
    pytest.skip('hidden test: graded by the instructor')


def test_unknown_by_variety():
    pytest.skip('hidden test: graded by the instructor')
