"""Level 4: replacing the shared tokenizer changes every service at once."""
import pytest


def test_policy_costs_search_one_ticket():
    pytest.skip('hidden test: graded by the instructor')


def test_bpe_removes_unknowns_but_breaks_the_rules():
    pytest.skip('hidden test: graded by the instructor')
