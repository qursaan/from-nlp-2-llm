"""Level 3: describe the training tickets before trusting their counts."""
from sanad import data
from sanad.corpus import counts, describe


def test_counts():
    c = counts([["the", "exam", "and"], ["the", "exam", "date"]])
    assert (c["tokens"], c["types"], c["hapax"]) == (6, 4, 2)
    assert c["ttr"] == 4 / 6
    assert counts([]) == {"tokens": 0, "types": 0, "hapax": 0, "ttr": None}


def test_describe_train_by_variety(pipeline_v1):
    d = describe(pipeline_v1.prep, data.tickets("train"))
    got = {v: (c["tokens"], c["types"], c["hapax"]) for v, c in d.items()}
    assert got == {"arabizi": (69, 56, 51), "egy": (66, 59, 54), "en": (178, 110, 91),
                   "msa": (98, 82, 70), "all": (411, 280, 226)}


def test_counts_depend_on_the_normaliser(pipeline_v0, pipeline_v1):
    raw = describe(pipeline_v0.prep, data.tickets("train"))["all"]
    norm = describe(pipeline_v1.prep, data.tickets("train"))["all"]
    assert raw["tokens"] == norm["tokens"] and norm["types"] < raw["types"]
