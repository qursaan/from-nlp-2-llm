"""Level 3: edit distance, and fuzzy search replaces exact search."""
from sanad import data, evaluate as ev
from sanad.edit import levenshtein
from sanad.search.v1_fuzzy import max_edits


def test_levenshtein():
    assert levenshtein("kitten", "sitting") == 3
    assert levenshtein("kitten", "sitting", sub_cost=2) == 5
    assert levenshtein("", "abc") == 3


def test_max_edits():
    assert [max_edits(w) for w in ("fee", "portal", "password")] == [0, 1, 2]


def test_fuzzy_tolerates_a_typo(pipeline_v1):
    assert pipeline_v1.search("v0_exact").search("pasword") == []
    assert pipeline_v1.search("v1_fuzzy").search("pasword")[0] == "F01"


def test_fuzzy_mrr_on_dev(pipeline_v1):
    dev = data.tickets("dev")
    exact = ev.search_report(pipeline_v1.search("v0_exact"), dev)["mrr"]
    fuzzy = ev.search_report(pipeline_v1.search("v1_fuzzy"), dev)["mrr"]
    assert fuzzy > exact
