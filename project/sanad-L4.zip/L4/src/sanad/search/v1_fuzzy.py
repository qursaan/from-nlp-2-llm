"""Search v1: exact overlap, but tolerate small spelling differences (Level 3; Book, Chapter 3).

A query token matches a passage token when their edit distance is at most
max_edits(token). Short tokens must match exactly: 'fee' and 'see' are one edit
apart and mean different things.
"""
from sanad.edit import levenshtein
from sanad.search.v0_exact import Search as Exact

LEVEL = 3
STUDENT = ("max_edits", "Search.matches", "Search.score")


def max_edits(token):
    """0 edits for tokens of up to 3 characters, 1 up to 6, then 2."""
    n = len(token)
    return 0 if n <= 3 else 1 if n <= 6 else 2


class Search(Exact):
    def matches(self, q, pid):
        """True if some token of passage pid is within max_edits(q) of q."""
        limit = max_edits(q)
        if limit == 0:
            return q in self.tokens[pid]
        return any(abs(len(q) - len(t)) <= limit and levenshtein(q, t) <= limit
                   for t in self.tokens[pid])

    def score(self, query_tokens, pid):
        """Number of distinct query tokens that match passage pid."""
        return sum(self.matches(q, pid) for q in set(query_tokens))
