"""Keyboard v0: suggest the most frequent training tokens (Level 4; Book, Chapter 3).

It ignores what was typed, so it is the baseline every keyboard must beat. Its
probability is an add-one unigram over the training vocabulary plus <unk>, so
an unseen target still has a probability and the perplexity stays finite.
"""
from collections import Counter

LEVEL = 4
STUDENT = ("Keyboard.fit", "Keyboard.suggest", "Keyboard.prob")
UNK = "<unk>"


class Keyboard:
    def __init__(self, prep):
        self.prep = prep
        self.counts = Counter()
        self.total = 0

    def fit(self, tickets):
        """Count the prepared tokens of the training tickets."""
        raise NotImplementedError("Level 4: fit")

    @property
    def vocab(self):
        return set(self.counts)

    def suggest(self, history, k=3):
        """The k most frequent tokens; ties alphabetical. history is ignored."""
        raise NotImplementedError("Level 4: suggest")

    def prob(self, history, word):
        """(c(w) + 1) / (N + V + 1), where an unseen word is <unk> with count 0."""
        raise NotImplementedError("Level 4: prob")
