"""Level 3: describe a split before trusting its counts (Book, Chapter 3).

Every count depends on the tokenization policy, so these functions take the
prepared token lists (prep = tokenizer after normaliser), never raw text.
A type seen exactly once is a hapax legomenon.
"""
from collections import Counter

LEVEL = 3
STUDENT = ("counts", "describe")


def counts(token_lists):
    """{"tokens": N, "types": V, "hapax": types seen once, "ttr": V/N or None}."""
    freq = Counter(t for ts in token_lists for t in ts)
    n = sum(freq.values())
    return {"tokens": n, "types": len(freq), "hapax": sum(c == 1 for c in freq.values()),
            "ttr": len(freq) / n if n else None}


def describe(prep, tickets):
    """{variety: counts(...)} for each variety in tickets, plus "all" for the whole split."""
    out = {}
    for v in sorted({t["variety"] for t in tickets}):
        out[v] = counts([prep(t["text"]) for t in tickets if t["variety"] == v])
    out["all"] = counts([prep(t["text"]) for t in tickets])
    return out
