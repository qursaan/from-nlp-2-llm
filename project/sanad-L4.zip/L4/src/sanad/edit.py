"""Level 3: minimum edit distance (Book, Chapter 3)."""
LEVEL = 3
STUDENT = ("levenshtein",)


def levenshtein(a, b, sub_cost=1):
    """Insertions and deletions cost 1, a substitution costs sub_cost."""
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1,
                           prev[j - 1] + (0 if ca == cb else sub_cost)))
        prev = cur
    return prev[-1]
