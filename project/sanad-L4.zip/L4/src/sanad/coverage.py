"""Level 4: how much of a split the training vocabulary covers (Book, Chapter 4).

A token never seen in training is unknown to every model fitted on training.
Changing the tokenizer changes this rate, and it differs by language variety.
"""
LEVEL = 4
STUDENT = ("unknown_rate", "unknown_by_variety")


def unknown_rate(vocab, token_lists):
    """Fraction of all tokens in token_lists that are not in vocab; None if no tokens."""
    raise NotImplementedError("Level 4: unknown_rate")


def unknown_by_variety(prep, train, tickets):
    """{variety: unknown_rate} for tickets, with the vocabulary of the prepared train tickets."""
    raise NotImplementedError("Level 4: unknown_by_variety")
