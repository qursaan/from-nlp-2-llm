"""Tokenizer v1: a declared policy instead of whitespace (Level 4; Book, Chapter 4).

TOKEN tries three alternatives in order, as Lab 1's N6 does:
  1. an Arabic word: Arabic letters and marks;
  2. a Latin or Arabizi word: letters and digits with at least one letter,
     plus an inner apostrophe ("can't", "3ayez", "nlp101");
  3. a run of digits, with an optional decimal part ("150.50").
Everything else, punctuation included, is dropped: "portal," becomes "portal".
"""
import re

LEVEL = 4
STUDENT = ("Tokenizer.tokenize",)

TOKEN = re.compile(r"[ء-يً-ْٰ]+"
                   r"|[0-9]*[a-z][a-z0-9]*(?:'[a-z]+)?"
                   r"|[0-9]+(?:\.[0-9]+)?")


class Tokenizer:
    def fit(self, texts):
        """Nothing to learn: the policy is written, not fitted."""
        return self

    def tokenize(self, text):
        """Every match of TOKEN, left to right."""
        raise NotImplementedError("Level 4: tokenize")
