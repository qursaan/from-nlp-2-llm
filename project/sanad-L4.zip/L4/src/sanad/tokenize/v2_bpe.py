"""Tokenizer v2: BPE learned from the training tickets (Level 4; Book, Chapter 4).

Words come from the v1 policy. Every word starts with the marker '_', as in the
book's leading-boundary learner, so '_re' (a word start) and 're' (inside a
word) are different pieces. Merges are learned from training text only, ties
broken by pair order; a character never seen in training stays a piece of its
own, so nothing is ever unknown to the tokenizer itself.
"""
from collections import Counter

from sanad.tokenize.v1_policy import Tokenizer as Policy

LEVEL = 4
STUDENT = ("merge", "Tokenizer.fit", "Tokenizer.encode_word")
MARK = "_"


def merge(pieces, pair):
    """Replace each non-overlapping occurrence of pair, left to right, by its join."""
    raise NotImplementedError("Level 4: merge")


class Tokenizer:
    def __init__(self, merges=300):
        self.n_merges = merges
        self.words = Policy()
        self.merges = []

    def fit(self, texts):
        """Learn up to n_merges merges from word counts; ties go to the smaller pair."""
        raise NotImplementedError("Level 4: fit")

    def encode_word(self, word):
        """The pieces of one word: start from characters, apply every merge in order."""
        raise NotImplementedError("Level 4: encode_word")

    def tokenize(self, text):
        return [p for w in self.words.tokenize(text) for p in self.encode_word(w)]
