"""Normaliser v2: Unicode NFC first, then the v1 policies (Level 4; Book, Chapter 4).

Two strings that look identical can use different code points: a precomposed
letter, or a base letter followed by a combining mark. NFC chooses one form,
so the later policies see the same input either way.
"""
import unicodedata

from sanad.normalize.v1_policies import normalize as policies

LEVEL = 4
STUDENT = ("normalize",)


def normalize(text):
    """NFC, then P1-P7 of normaliser v1."""
    raise NotImplementedError("Level 4: normalize")
