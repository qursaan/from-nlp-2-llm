"""Router v1: keyword patterns per intent (Level 2; Book, Chapter 2).

Patterns run on the prepared text (normalised tokens joined by spaces). Each
intent scores the number of its patterns that match; the highest score wins,
ties go to the earlier intent in RULES, and no match returns None so that the
clarifier can ask.
"""
import re

LEVEL = 2
STUDENT = ("Router.fit", "Router.scores", "Router.predict")

# Sanad knows one intent so far. Add patterns for the other four in English,
# MSA, Egyptian, and Arabizi, written from the TRAINING tickets only. Write
# them for normalised text: alef variants are ا, ة is ه, Latin is lower case.
RULES = {
    "access": [r"log ?in|password|portal|wi-?fi|account|locked|course page",
               r"البوابه|كلمه المرور|الباسورد|الدخول|ادخل|بشبكه|صفحه",
               r"a5osh|password|portal|saf7et"],
    "assessment": [],
    "registration": [],
    "fees": [],
    "other": [],
}


class Router:
    def __init__(self, prep):
        self.prep = prep
        self.patterns = {}

    def fit(self, tickets):
        """Compile RULES; the training tickets are for your own checking, not learning."""
        raise NotImplementedError("Level 2: fit")

    def scores(self, text):
        """{intent: number of its patterns found in the prepared text}."""
        raise NotImplementedError("Level 2: scores")

    def predict(self, text):
        """Best-scoring intent; ties go to the earlier intent; None if nothing matched."""
        raise NotImplementedError("Level 2: predict")
