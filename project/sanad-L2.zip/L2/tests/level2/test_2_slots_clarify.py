"""Level 2: slot extraction and the clarifier."""
import pytest


def test_course():
    pytest.skip('hidden test: graded by the instructor')


def test_amount():
    pytest.skip('hidden test: graded by the instructor')


def test_room_number_is_not_an_amount():
    pytest.skip('hidden test: graded by the instructor')


def test_clarifier():
    pytest.skip('hidden test: graded by the instructor')
