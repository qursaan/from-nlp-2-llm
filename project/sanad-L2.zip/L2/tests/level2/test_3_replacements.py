"""Level 2: the rule router replaces the v0 majority router."""
import pytest


def test_rules_cover_the_training_tickets():
    pytest.skip('hidden test: graded by the instructor')


def test_rules_decline_and_break_ties():
    pytest.skip('hidden test: graded by the instructor')


def test_rules_beat_the_baseline_on_dev():
    pytest.skip('hidden test: graded by the instructor')
