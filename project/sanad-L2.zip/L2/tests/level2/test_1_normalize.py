"""Level 2: the declared normalisation policies."""
import pytest


def test_marks_and_tatweel():
    pytest.skip('hidden test: graded by the instructor')


def test_letters():
    pytest.skip('hidden test: graded by the instructor')


def test_digits():
    pytest.skip('hidden test: graded by the instructor')


def test_elongation():
    pytest.skip('hidden test: graded by the instructor')


def test_order_and_case():
    pytest.skip('hidden test: graded by the instructor')
