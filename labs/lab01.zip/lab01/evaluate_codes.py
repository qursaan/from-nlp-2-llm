"""Score find_course_codes on an annotated message set.

Run: python evaluate_codes.py                      # the supplied set
     python evaluate_codes.py data/my_codes.tsv    # your own cases

Each line of the TSV file is a message, a tab, and its true codes in the
normalised form find_course_codes returns (CS101, MATH205), separated by ';'.
Within a message, a returned code is correct if it matches a true code that
has not been matched yet; each true code can be matched once.

Scoring contract: this compares code VALUES per message, not positions,
because find_course_codes returns codes without offsets. The book's exact-span
scorer (Figure 2.6) is stricter: in "CS101 then CS101" with one true code, the
second CS101, a span that returned the wrong occurrence scores 0 there but
1 here. Use exact spans when the position matters, e.g. to highlight a code.
"""
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from arabic_nlp.normalize import find_course_codes  # noqa: E402


def load(path):
    lines = Path(path).read_text(encoding="utf-8").splitlines()[1:]   # skip the header
    for line in lines:
        text, _, codes = line.partition("\t")
        yield text, [c for c in codes.split(";") if c]


def score(path):
    tp = fp = fn = 0
    for text, gold in load(path):
        found, true = Counter(find_course_codes(text)), Counter(gold)
        hit = sum((found & true).values())
        tp, fp, fn = tp + hit, fp + sum(found.values()) - hit, fn + sum(true.values()) - hit
        if found != true:
            print(f"  {text!r}: returned {sorted(found.elements())}, true {sorted(true.elements())}")
    precision = tp / (tp + fp) if tp + fp else float("nan")
    recall = tp / (tp + fn) if tp + fn else float("nan")
    print(f"TP={tp} FP={fp} FN={fn}  precision={precision:.3f}  recall={recall:.3f}")
    return tp, fp, fn


if __name__ == "__main__":
    score(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent / "data/course_codes.tsv")
