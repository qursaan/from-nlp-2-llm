"""Lab 1 starter: Arabic normalisation and tokenization with regular expressions.

Every function implements one written policy (N1-N8). A policy is a choice for a
task, not a universal truth about Arabic: search may merge forms that a
pronunciation system must keep apart.
"""
import re

# TODO: compile one pattern per policy. Useful ranges and code points:
#   letters U+0621-U+063A and U+0641-U+064A      tatweel U+0640
#   harakat, tanween, shadda, sukun U+064B-U+0652  dagger alef U+0670
#   alef forms آ U+0622, أ U+0623, إ U+0625, ٱ U+0671
#   Arabic-Indic digits U+0660-U+0669, Persian digits U+06F0-U+06F9
DIACRITICS = None     # N1
TATWEEL = None        # N2
ALEF_VARIANTS = None  # N3
TOKEN = None          # N6: Arabic word | Latin/Arabizi word | digit run
NUMBER = None         # N7a: a digit run in any of the three scripts
COURSE_CODE = None    # N7b: 2-4 capitals, optional space, three digits
CLITIC_PREFIX = None  # N8: optional و/ف, then optional ب/ك/ل, then optional ال

# N5 needs no regular expression: str.translate with this table is enough.
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def remove_diacritics(text):
    """N1: delete short-vowel marks, tanween, shadda, sukun and dagger alef."""
    raise NotImplementedError("TODO: remove_diacritics")


def remove_tatweel(text):
    """N2: delete the presentation stretch U+0640; never delete a letter."""
    raise NotImplementedError("TODO: remove_tatweel")


def normalize_alef(text):
    """N3: map آ أ إ ٱ to bare alef ا."""
    raise NotImplementedError("TODO: normalize_alef")


def normalize_ya_ta(text):
    """N4: map alef maqsura ى to ya ي and taa marbuta ة to haa ه."""
    raise NotImplementedError("TODO: normalize_ya_ta")


def to_western_digits(text):
    """N5: map Arabic-Indic and Persian digits to 0-9; leave everything else."""
    raise NotImplementedError("TODO: to_western_digits")


def tokenize(text):
    """N6: return Arabic words, Latin/Arabizi words and digit runs, in order.

    Punctuation (including ، ؛ ؟) and whitespace are separators. Diacritics and
    tatweel stay inside the Arabic word they belong to.
    """
    raise NotImplementedError("TODO: tokenize")


def extract_numbers(text):
    """N7a: every digit run, in either script, as an int."""
    raise NotImplementedError("TODO: extract_numbers")


def find_course_codes(text):
    """N7b: codes such as CS101, CS 101 or CS ١٠١, returned as 'CS101'."""
    raise NotImplementedError("TODO: find_course_codes")


def strip_clitics(word, min_stem=3):
    """N8: remove an optional و/ف, then ب/ك/ل, then ال, if a stem of at least
    min_stem letters remains; otherwise return the word unchanged.

    This is a deliberately naive string rule. It cannot tell a clitic from a
    root letter, and it does not handle the contraction لل (ل + ال).
    """
    raise NotImplementedError("TODO: strip_clitics")


def normalize(text):
    """Search policy: N1, N2, N3, N4 and N5 in that order."""
    raise NotImplementedError("TODO: normalize")
