"""Lab 1: Arabic normalisation and tokenization."""
