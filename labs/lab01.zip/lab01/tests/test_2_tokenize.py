"""Policies N6-N7: token boundaries and extraction."""
import pytest


def test_n6_punctuation_is_a_separator():
    pytest.skip('hidden test: graded by the instructor')


def test_n6_keeps_diacritics_inside_a_word():
    pytest.skip('hidden test: graded by the instructor')


def test_n6_mixed_arabic_english_and_arabizi():
    pytest.skip('hidden test: graded by the instructor')


def test_n7_numbers_in_both_scripts():
    pytest.skip('hidden test: graded by the instructor')


def test_n7_course_codes_are_canonical():
    pytest.skip('hidden test: graded by the instructor')
