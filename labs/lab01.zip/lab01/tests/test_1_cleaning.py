"""Policies N1-N5. Each expected value follows from the written policy."""
import pytest


def test_n1_removes_harakat_tanween_and_shadda():
    pytest.skip('hidden test: graded by the instructor')


def test_n1_keeps_letters_and_latin_text():
    pytest.skip('hidden test: graded by the instructor')


def test_n2_removes_only_the_stretch():
    pytest.skip('hidden test: graded by the instructor')


def test_n3_merges_alef_forms():
    pytest.skip('hidden test: graded by the instructor')


def test_n4_maps_maqsura_and_taa_marbuta():
    pytest.skip('hidden test: graded by the instructor')


def test_n5_converts_arabic_indic_digits():
    pytest.skip('hidden test: graded by the instructor')


def test_search_policy_makes_variants_equal():
    pytest.skip('hidden test: graded by the instructor')
