"""Policy N8: a naive clitic rule, with its known false results recorded."""
import pytest


def test_n8_strips_prefix_clitics():
    pytest.skip('hidden test: graded by the instructor')


def test_n8_minimum_stem_protects_short_roots():
    pytest.skip('hidden test: graded by the instructor')


def test_n8_known_failure_contracted_article():
    pytest.skip('hidden test: graded by the instructor')


def test_n8_known_failure_root_initial_letter():
    pytest.skip('hidden test: graded by the instructor')


def test_n8_known_failure_greedy_preposition():
    pytest.skip('hidden test: graded by the instructor')
