"""Lab 1, public checks: these ship to students unhidden.

Every expected value here is printed in the book (Chapter 2, Figure 2.4 and
Example 2.2), so nothing graded is revealed. The other test_*.py files are the
graded tests: they show as skipped until marking.

    python -m pytest tests/test_public_checks.py -v
"""
import pytest

from arabic_nlp.normalize import (find_course_codes, normalize_alef, remove_diacritics,
                                  strip_clitics, tokenize)


def test_n1_vocalised_word_becomes_one_word():
    assert remove_diacritics("يَدْرُسُونَ") == "يدرسون"


def test_n3_alef_with_hamza_becomes_bare_alef():
    assert normalize_alef("أحمد") == "احمد"


def test_n6_mixed_request_gives_nine_tokens():
    text = "3ayez a5ls el project بكرة، والـ deadline ١٥ مايو!"
    assert tokenize(text) == ["3ayez", "a5ls", "el", "project", "بكرة",
                              "والـ", "deadline", "١٥", "مايو"]


def test_n7_course_codes_from_example_2_2():
    assert find_course_codes("Registered CS101 and MATH 205") == ["CS101", "MATH205"]


def test_n8_strips_clitics_but_keeps_short_roots():
    assert strip_clitics("والطلاب") == "طلاب"
    assert strip_clitics("وصل") == "وصل"


# The book's three known failures of N8. strict=True: each must keep FAILING.
# If one passes, your rule differs from the written policy (lab step 4).
@pytest.mark.xfail(strict=True, raises=AssertionError, reason="li- + al- contracts to lil-, which N8 does not model")
def test_n8_known_failure_lil():
    assert strip_clitics("للطلاب") == "طلاب"


@pytest.mark.xfail(strict=True, raises=AssertionError, reason="the greedy preposition group takes the root letter k")
def test_n8_known_failure_fa_kataba():
    assert strip_clitics("فكتب") == "كتب"


@pytest.mark.xfail(strict=True, raises=AssertionError, reason="the b of bahthuna is a root letter, not bi-")
def test_n8_known_failure_bahthuna():
    assert strip_clitics("بحثنا") == "بحثنا"
