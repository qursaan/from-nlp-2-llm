"""Lab 3 starter: reading the corpus and corpus statistics (C1-C4)."""
import re
from collections import Counter

MARKS = re.compile(r"[\u064B-\u0652\u0670\u0640]")  # diacritics and tatweel
WORD = re.compile(r"[\u0621-\u063A\u0641-\u064A]+")
ALEF = re.compile(r"[\u0622\u0623\u0625\u0671]")


def tokens(line, normalize=False):
    """C1: Arabic word tokens of one line, after removing diacritics and
    tatweel. With normalize=True also map alef forms to ا, ى to ي, ة to ه."""
    raise NotImplementedError("TODO: tokens")


def read_corpus(path, normalize=False):
    """C1: one token list per non-empty, non-comment line."""
    raise NotImplementedError("TODO: read_corpus")


def type_token(sentences):
    """C2: (number of tokens N, number of types V)."""
    raise NotImplementedError("TODO: type_token")


def zipf_table(sentences, k=10):
    """C3: the k most frequent words as (rank, word, freq, rank * freq).

    Ties are broken alphabetically so the table is reproducible.
    """
    raise NotImplementedError("TODO: zipf_table")


def hapax(sentences):
    """C3: words that occur exactly once, sorted."""
    raise NotImplementedError("TODO: hapax")


def heaps_curve(sentences):
    """C4: (tokens so far, types so far) after each sentence."""
    raise NotImplementedError("TODO: heaps_curve")
