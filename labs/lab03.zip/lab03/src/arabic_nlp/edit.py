"""Lab 3 starter: minimum edit distance (D1-D6)."""
import math


def distance_table(source, target, sub_cost=1):
    """D1: the full (len(source)+1) x (len(target)+1) Levenshtein table.

    D[i][j] = min(D[i-1][j] + 1, D[i][j-1] + 1,
                  D[i-1][j-1] + (0 if equal else sub_cost))
    """
    raise NotImplementedError("TODO: distance_table")


def levenshtein(source, target, sub_cost=1):
    """D1: the bottom-right cell of distance_table."""
    raise NotImplementedError("TODO: levenshtein")


def closest(word, lexicon, sub_cost=1):
    """D2: the lexicon entry nearest to word (ties alphabetical)."""
    raise NotImplementedError("TODO: closest")


def weighted_distance(source, target, delete, insert, substitute):
    """D3: minimum total cost with per-symbol costs (book Section "Weighted
    edit distance"). delete(x), insert(y) and substitute(x, y) return finite,
    non-negative costs; equal symbols cost 0. The borders accumulate the real
    costs: D[i][0] = D[i-1][0] + delete(source[i-1]), and likewise D[0][j].
    Raise ValueError for a negative or non-finite cost."""
    raise NotImplementedError("TODO: weighted_distance")


def align(source, target, sub_cost=1):
    """D4: backtrace one best path through distance_table. Return
    (source row, target row, operations): the rows use "*" for a gap and the
    operations are M, S, I, D, in reading order. Test the diagonal first, so
    a tie goes to a match or a substitution (book Section "Backtrace")."""
    raise NotImplementedError("TODO: align")


def wer(reference, hypothesis):
    """D5: word error rate of one sentence pair, (S + D + I) / N, over the
    whitespace words of each string, with every edit costing 1. Return a
    dict with keys "S", "D", "I", "N" and "wer". Raise ValueError for an
    empty reference, where WER is undefined."""
    raise NotImplementedError("TODO: wer")


def corpus_wer(pairs):
    """D5: WER of a test set of (reference, hypothesis) pairs: add up the
    edits and the reference words of every pair first, then divide once.
    Do not average the sentence WERs."""
    raise NotImplementedError("TODO: corpus_wer")


def swap_distance(source, target):
    """D6: Levenshtein plus a fourth move, swapping two neighbouring letters
    at cost 1 (the optimal-string-alignment form of Damerau-Levenshtein). Try
    the swap while the table is filled, so that it reaches every later cell:
    if source[i-2:i] is target[j-2:j] reversed, D[i][j] may come from
    D[i-2][j-2] + 1."""
    raise NotImplementedError("TODO: swap_distance")
