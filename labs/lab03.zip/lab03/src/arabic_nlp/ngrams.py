"""Lab 3 starter: n-gram windows, a bigram language model, sampling,
and interpolation (G1-G7).

Padding follows the book: n-1 start markers and one end marker for n > 1.
The model predicts words and </s>; <s> is context only, never a target.

The target support is fixed by fit() from training data alone. A target
outside the support has probability zero. With unk=True the support also
reserves <unk>, and every word not seen in training is mapped to it, as a
target and as a context, before scoring.
"""
import math
from collections import Counter

BOS, EOS, UNK = "<s>", "</s>", "<unk>"


def ngrams(tokens, n, pad=True):
    """G1: the n-gram windows of one sentence, as tuples."""
    raise NotImplementedError("TODO: ngrams")


class BigramLM:
    """G2-G6: a bigram model with optional add-one smoothing."""

    def __init__(self, add_one=False, unk=False):
        raise NotImplementedError("TODO: __init__")

    def fit(self, sentences):
        """G2: count padded bigram transitions; return self. The targets seen
        here, plus <unk> when unk=True, are the model's fixed support."""
        raise NotImplementedError("TODO: fit")

    def map(self, w):
        """G3: the symbol scored for w: w itself, or <unk> when unk=True and
        w was never a training target. <s> is always kept."""
        raise NotImplementedError("TODO: map")

    def prob(self, b, a):
        """G3: P(b | a) over the fitted support, after mapping a and b.
        A target outside the support has probability 0.
        MLE: C(a,b)/C_out(a), or 0 for an unseen context.
        Add-one: (C(a,b)+1)/(C_out(a)+V), with V the number of targets."""
        raise NotImplementedError("TODO: prob")

    def logprob(self, tokens):
        """G4: natural-log probability of a sentence including </s>.
        Returns -inf when any factor is zero."""
        raise NotImplementedError("TODO: logprob")

    def perplexity(self, sentences):
        """G4: exp of the average negative log probability per target
        (each sentence contributes len(sentence) + 1 targets)."""
        raise NotImplementedError("TODO: perplexity")

    def generate(self, max_len=12):
        """G5: greedy decoding from <s>: always take the most probable next
        word (ties alphabetical), stop at </s> or after max_len words."""
        raise NotImplementedError("TODO: generate")

    def sample(self, rng, max_len=12):
        """G6: draw a sentence from <s> with inverse-CDF sampling.

        In each context, order the support by token text, draw u = rng.random()
        in [0, 1), and take the first target whose cumulative probability
        exceeds u. Stop at </s> (status "end") or after max_len words (status
        "budget"). Returns (words, status); </s> is never in words."""
        raise NotImplementedError("TODO: sample")


class InterpolatedLM:
    """G7: lam * P_bigram(b | a) + (1 - lam) * P_unigram(b), over the bigram's
    fixed support. The unigram is add-one over that support, so every target,
    including <unk>, has positive probability. A context never seen in training
    has no bigram row; it uses the unigram alone."""

    def __init__(self, bigram, lam):
        raise NotImplementedError("TODO: __init__ (reject lam outside [0, 1])")

    def unigram_prob(self, b):
        raise NotImplementedError("TODO: unigram_prob")

    def prob(self, b, a):
        raise NotImplementedError("TODO: prob")

    # Scoring is the same as for the bigram model: only prob differs.
    logprob = BigramLM.logprob
    perplexity = BigramLM.perplexity


def choose_lambda(bigram, dev, grid=(0, .25, .5, .75, 1)):
    """G7: the grid weight with the lowest dev perplexity (ties: smaller lam),
    and every weight's dev perplexity. Never call this with test data."""
    raise NotImplementedError("TODO: choose_lambda")
