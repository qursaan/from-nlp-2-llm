from pathlib import Path

import pytest

from arabic_nlp.corpus import read_corpus

CORPUS = Path(__file__).resolve().parents[1] / "data" / "corpus_ar.txt"


@pytest.fixture
def corpus():
    return read_corpus(CORPUS)


@pytest.fixture
def normalized_corpus():
    return read_corpus(CORPUS, normalize=True)


@pytest.fixture
def tiny():
    # The book's worked example (Chapter 4): three short requests.
    return [["أريد", "تأجيل", "الاختبار"],
            ["أريد", "تأجيل", "التسليم"],
            ["متى", "الاختبار"]]
