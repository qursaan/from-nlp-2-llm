"""D1-D6: minimum edit distance, backtrace, WER, and a swap move."""
import pytest


def test_d1_levenshtein():
    pytest.skip('hidden test: graded by the instructor')


def test_d1_table_borders_and_corner():
    pytest.skip('hidden test: graded by the instructor')


def test_d1_swapped_letters_worked_table():
    pytest.skip('hidden test: graded by the instructor')


def test_d1_substitution_cost_two_matches_insert_plus_delete():
    pytest.skip('hidden test: graded by the instructor')


def test_d2_closest_lexicon_entry():
    pytest.skip('hidden test: graded by the instructor')


def test_d3_directed_spelling_costs():
    pytest.skip('hidden test: graded by the instructor')


def test_d3_unit_costs_match_levenshtein():
    pytest.skip('hidden test: graded by the instructor')


def test_d3_borders_accumulate_real_costs():
    pytest.skip('hidden test: graded by the instructor')


def test_d3_a_costly_substitution_loses_to_delete_plus_insert():
    pytest.skip('hidden test: graded by the instructor')


def test_d3_rejects_bad_costs():
    pytest.skip('hidden test: graded by the instructor')


def test_d4_backtrace_rows_and_operations():
    pytest.skip('hidden test: graded by the instructor')


def test_d5_sentence_wer_counts():
    pytest.skip('hidden test: graded by the instructor')


def test_d5_empty_reference_is_undefined():
    pytest.skip('hidden test: graded by the instructor')


def test_d5_corpus_wer_pools_instead_of_averaging():
    pytest.skip('hidden test: graded by the instructor')


def test_d6_swap_move():
    pytest.skip('hidden test: graded by the instructor')
