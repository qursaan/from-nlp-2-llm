"""C1-C4: tokens, types, Zipf and Heaps on the help-desk corpus."""
import pytest


def test_c1_tokens_drop_marks_digits_and_punctuation():
    pytest.skip('hidden test: graded by the instructor')


def test_c1_tatweel_is_removed():
    pytest.skip('hidden test: graded by the instructor')


def test_c1_normalize_merges_spelling_variants():
    pytest.skip('hidden test: graded by the instructor')


def test_c1_corpus_has_forty_requests():
    pytest.skip('hidden test: graded by the instructor')


def test_c2_tokens_and_types():
    pytest.skip('hidden test: graded by the instructor')


def test_c2_normalisation_reduces_types_not_tokens():
    pytest.skip('hidden test: graded by the instructor')


def test_c3_zipf_table_is_ranked_and_tie_broken():
    pytest.skip('hidden test: graded by the instructor')


def test_c3_most_frequent_word_in_corpus():
    pytest.skip('hidden test: graded by the instructor')


def test_c3_hapax():
    pytest.skip('hidden test: graded by the instructor')


def test_c4_heaps_curve_is_cumulative():
    pytest.skip('hidden test: graded by the instructor')
