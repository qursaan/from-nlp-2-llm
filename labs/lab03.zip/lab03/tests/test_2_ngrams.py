"""G1-G7: padded windows, a bigram model, sampling, and interpolation."""
import pytest


def test_g1_unpadded_windows():
    pytest.skip('hidden test: graded by the instructor')


def test_g1_padded_trigrams_use_two_start_markers():
    pytest.skip('hidden test: graded by the instructor')


def test_g1_unigrams_are_never_padded():
    pytest.skip('hidden test: graded by the instructor')


def test_g2_g3_mle_uses_outgoing_counts():
    pytest.skip('hidden test: graded by the instructor')


def test_g3_unseen_transition_is_zero_without_smoothing():
    pytest.skip('hidden test: graded by the instructor')


def test_g3_add_one_counts_targets_not_start_marker():
    pytest.skip('hidden test: graded by the instructor')


def test_g4_sentence_logprob():
    pytest.skip('hidden test: graded by the instructor')


def test_g4_zero_factor_gives_minus_infinity():
    pytest.skip('hidden test: graded by the instructor')


def test_g4_perplexity_counts_end_marker():
    pytest.skip('hidden test: graded by the instructor')


def test_g4_smoothing_keeps_unseen_requests_finite():
    pytest.skip('hidden test: graded by the instructor')


def test_g5_greedy_generation_is_deterministic():
    pytest.skip('hidden test: graded by the instructor')


def test_g3_target_outside_support_has_zero_probability():
    pytest.skip('hidden test: graded by the instructor')


def test_g3_unk_is_reserved_in_the_fitted_support():
    pytest.skip('hidden test: graded by the instructor')


def test_g4_held_out_perplexity_needs_an_unknown_policy():
    pytest.skip('hidden test: graded by the instructor')


def test_g6_sampling_is_reproducible_with_a_seed():
    pytest.skip('hidden test: graded by the instructor')


def test_g6_budget_stop_is_reported():
    pytest.skip('hidden test: graded by the instructor')


def test_g6_samples_never_contain_markers():
    pytest.skip('hidden test: graded by the instructor')


def test_g7_interpolated_rows_sum_to_one():
    pytest.skip('hidden test: graded by the instructor')


def test_g7_weight_must_be_a_probability():
    pytest.skip('hidden test: graded by the instructor')


def test_g7_lambda_is_chosen_on_dev_not_test():
    pytest.skip('hidden test: graded by the instructor')
