"""Lab 2: an Arabic ELIZA."""
