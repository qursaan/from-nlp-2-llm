"""Lab 2 starter: a small Arabic ELIZA for a university help desk.

ELIZA (Weizenbaum, 1966) finds the highest-ranked keyword, decomposes the input
with that keyword's pattern, reflects the captured phrase and reassembles it
into a template. Nothing here understands the request; that is the lesson.
"""
import re
from dataclasses import dataclass

CLEAN = re.compile(r"[\u064B-\u0652\u0670\u0640]")  # diacritics and tatweel
TRAILING = re.compile(r"[\s.!?؟،,؛]+$")

# E3: whole-word pronoun reflection, in both directions.
REFLECTIONS = {
    "أنا": "أنت", "انا": "أنت", "أنت": "أنا", "انت": "أنا",
    "لي": "لك", "لك": "لي", "عندي": "عندك", "عندك": "عندي",
    "نحن": "أنتم", "أنتم": "نحن",
}
# E3: words ending in ي that are not a first-person possessive suffix.
NOT_POSSESSIVE = {"في", "الذي", "التي", "كي", "حتى", "علي"}


@dataclass
class Rule:
    keyword: str
    rank: int
    pattern: str
    templates: list

    def __post_init__(self):
        self.regex = re.compile(self.pattern)


# Higher rank wins when several keywords occur in one input (E2).
RULES = [
    Rule("اختبار", 5, r"(?:امتحان|اختبار)",
         ["حدثني أكثر عن الاختبار.", "ما الذي يقلقك في الاختبار؟"]),
    Rule("أستطيع", 4, r"لا\s+[أا]ستطيع\s+(.+)",
         ["ما الذي يمنعك من {0}؟", "هل جربت طريقة أخرى ل{0}؟"]),
    Rule("أشعر", 3, r"[أا]شعر\s+(?:ب)?(.+)",
         ["لماذا تشعر ب{0}؟", "منذ متى تشعر ب{0}؟"]),
    Rule("عائلة", 3, r"(?:[أا]مي|[أا]بي|عائلتي|[أا]سرتي)",
         ["حدثني أكثر عن عائلتك."]),
    Rule("أريد", 2, r"[أا]ريد\s+(?:[أا]ن\s+)?(.+)",
         ["لماذا تريد {0}؟", "ماذا سيحدث لو حصلت على {0}؟"]),
    Rule("أنا", 1, r"^[أا]نا\s+(.+)",
         ["منذ متى وأنت {0}؟", "هل تعتقد أنك {0} حقا؟"]),
]
FALLBACKS = ["حدثني أكثر.", "أفهم. تابع من فضلك.", "كيف يجعلك ذلك تشعر؟"]


def clean(text):
    """E1: remove diacritics and tatweel, collapse spaces, trim punctuation."""
    raise NotImplementedError("TODO: clean")


def reflect_word(word):
    """E3: swap first and second person in one word.

    Whole pronouns use REFLECTIONS. Otherwise a final ي on a word of four or
    more letters is read as 'my' and becomes ك ('your'), unless the word is in
    NOT_POSSESSIVE. The suffix rule is a string heuristic with known failures.
    """
    raise NotImplementedError("TODO: reflect_word")


def reflect(phrase):
    """E3: reflect every space-separated word of a phrase."""
    raise NotImplementedError("TODO: reflect")


def select_rule(text):
    """E2: the highest-ranked rule whose pattern matches, or None.

    Ties keep the order of RULES.
    """
    raise NotImplementedError("TODO: select_rule")


def respond(text, turn=0):
    """E4: one reply. The template is chosen by turn, so runs are repeatable."""
    raise NotImplementedError("TODO: respond")


def converse(lines):
    """Replies to a list of user lines, numbering the turns from 0."""
    raise NotImplementedError("TODO: converse")
