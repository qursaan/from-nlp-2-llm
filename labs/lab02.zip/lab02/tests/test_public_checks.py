"""Lab 2, public checks: these ship to students unhidden.

Every expected value here is printed in the book (Chapter 2, Figure 2.12, the
Arabic ELIZA session) or in the starter itself (FALLBACKS), so nothing graded
is revealed. The other test_*.py files are the graded tests: they show as
skipped until marking.

    python -m pytest tests/test_public_checks.py -v
"""
import pytest

from arabic_nlp.eliza import FALLBACKS, converse, reflect, respond, select_rule


def test_e3_possessive_suffix_is_reflected():
    assert reflect("مستقبلي") == "مستقبلك"


def test_e2_exam_rule_outranks_i_want():
    # Turn 3 of Figure 2.12: "I want" (rank 2) and "the exam" (rank 5).
    assert select_rule("أريد تأجيل الاختبار").keyword == "اختبار"


def test_e4_turn_0_of_figure_2_12():
    assert respond("أنا قلق على مستقبلي") == "منذ متى وأنت قلق على مستقبلك؟"


def test_converse_gives_one_reply_per_line():
    assert converse(["مرحبا", "شكرا"]) == FALLBACKS[:2]


# The book's known failure of reflection. strict=True: it must keep FAILING.
@pytest.mark.xfail(strict=True, raises=AssertionError, reason="nisba adjectives also end in -i")
def test_e3_known_failure_nisba_adjective():
    assert reflect("طالب عربي") == "طالب عربي"
