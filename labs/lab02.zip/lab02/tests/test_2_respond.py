"""E2 and E4: keyword ranking, decomposition and reassembly."""
import pytest


def test_e2_highest_rank_wins():
    pytest.skip('hidden test: graded by the instructor')


def test_e2_no_keyword_selects_no_rule():
    pytest.skip('hidden test: graded by the instructor')


def test_e4_feeling_rule_reassembles_the_capture():
    pytest.skip('hidden test: graded by the instructor')


def test_e4_capture_is_reflected():
    pytest.skip('hidden test: graded by the instructor')


def test_e4_hamza_variant_still_matches():
    pytest.skip('hidden test: graded by the instructor')


def test_e4_cannot_rule_outranks_i_rule():
    pytest.skip('hidden test: graded by the instructor')


def test_e4_turn_selects_the_template():
    pytest.skip('hidden test: graded by the instructor')


def test_e4_fallback_cycles_by_turn():
    pytest.skip('hidden test: graded by the instructor')
