"""E1 and E3: cleaning and pronoun reflection."""
import pytest


def test_e1_clean_removes_marks_and_final_punctuation():
    pytest.skip('hidden test: graded by the instructor')


def test_e3_whole_pronouns_swap():
    pytest.skip('hidden test: graded by the instructor')


def test_e3_possessive_suffix_becomes_your():
    pytest.skip('hidden test: graded by the instructor')


def test_e3_function_words_are_protected():
    pytest.skip('hidden test: graded by the instructor')


def test_e3_short_words_are_left_alone():
    pytest.skip('hidden test: graded by the instructor')


def test_e3_known_failure_nisba_adjective():
    pytest.skip('hidden test: graded by the instructor')
