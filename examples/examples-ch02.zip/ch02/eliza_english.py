"""Chapter 2: the four ELIZA mechanisms in a dozen lines (English).

Run: python3 examples/ch02/eliza_english.py
Lab 2 builds the Arabic version, where reflection becomes a morphology problem.
"""
import re

REFLECT = {"i": "you", "my": "your", "me": "you", "am": "are", "you": "I", "your": "my"}
RULES = [  # (rank, decomposition pattern, reassembly templates)
    (3, r"\bi feel (.+)", ["Why do you feel {0}?"]),
    (1, r"\bi am (.+)", ["How long have you been {0}?", "Do you believe you are {0}?"]),
]
FALLBACK = ["Please go on.", "Tell me more."]


def reflect(phrase):
    return " ".join(REFLECT.get(w, w) for w in phrase.split())


def respond(text, turn=0):
    text = text.lower().strip(" .!?")
    matches = [(rank, m, t) for rank, p, t in RULES if (m := re.search(p, text))]
    if not matches:
        return FALLBACK[turn % len(FALLBACK)]
    _, match, templates = max(matches, key=lambda r: r[0])
    return templates[turn % len(templates)].format(reflect(match.group(1)))


assert respond("I am worried about my exams.") == \
    "How long have you been worried about your exams?"
assert respond("I am sure I feel tired") == "Why do you feel tired?"   # rank 3 wins
assert respond("Hello") == "Please go on."

if __name__ == "__main__":
    for line in ["I am worried about my exams.", "I am sure I feel tired", "Hello"]:
        print(f"> {line}\n  {respond(line)}")
