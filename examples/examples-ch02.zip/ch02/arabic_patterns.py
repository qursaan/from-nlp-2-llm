"""Arabic patterns, step by step: the six worked examples of Chapter 2.

Each block builds one pattern, tries it on constructed help-desk messages, and
asserts what the chapter prints: what it finds, what it rejects, and the known
failure it leaves. Run: python3 examples/ch02/arabic_patterns.py
"""

import re

from regex_policies import normalize_alef, remove_diacritics


def normalize_ya_ta(text):          # N4: alef maqsura to ya, taa marbuta to haa
    return text.replace("ى", "ي").replace("ة", "ه")

AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")   # policy N5


def to_ascii_digits(text):
    return text.translate(AR_DIGITS)


# --- W1. A word, not a piece of a word: the negation "mish". -----------------------
MISH_NAIVE = re.compile(r"مش")                 # m-sh anywhere
MISH_WORD = re.compile(r"\bمش\b")              # m-sh as a whole word
MISH_CLITIC = re.compile(r"\b[وف]?مش\b")       # ... or with "and"/"so" attached

PROBLEM = "عندي مشكلة في التسجيل"          # 3andi mushkila fi el-tasgil: a problem
PROJECT = "المشروع اتسلم امبارح"             # el-mashru3 etsallem embareh: project handed in
NEGATED = "انا مش عارف الباسورد"             # ana mish 3arif: I don't know the password
AND_NOT = "ومش لاقي الجدول"                 # w-mish la2i: and I can't find the timetable

assert MISH_NAIVE.search(PROBLEM) and MISH_NAIVE.search(PROJECT)   # two false alarms
assert not MISH_WORD.search(PROBLEM) and not MISH_WORD.search(PROJECT)
assert MISH_WORD.search(NEGATED)
assert not MISH_WORD.search(AND_NOT)            # wa- glued on: no boundary before m
assert MISH_CLITIC.search(AND_NOT) and MISH_CLITIC.search(NEGATED)
assert not MISH_CLITIC.search(PROBLEM)
# Known failure: a word that is "wa" + "mish..." still slips through the clitic class.
assert MISH_CLITIC.search("ومش") and not MISH_CLITIC.search("ومشكلة")
assert MISH_CLITIC.search("فمش")                   # fa-mish, "so not"
# Run N1 first: a vowel mark inside mish splits the two letters.
assert not MISH_CLITIC.search("انا مِش عارف")
assert MISH_CLITIC.search(remove_diacritics("انا مِش عارف"))


# --- W2. Search that forgives spelling, without changing the text. -----------------
# One class per letter that users spell in more than one way (N3 and N4 as a search).
VARIANTS = {"ا": "[اأإآ]", "أ": "[اأإآ]", "إ": "[اأإآ]", "آ": "[اأإآ]",
            "ة": "[ةه]", "ه": "[ةه]", "ى": "[يى]", "ي": "[يى]"}


def tolerant(word):
    """A pattern that accepts every common spelling of `word`."""
    return "".join(VARIANTS.get(ch, re.escape(ch)) for ch in word)


TEST = "الاختبار"                                # al-ikhtibar, the test
assert tolerant(TEST) == "[اأإآ]ل[اأإآ]ختب[اأإآ]ر"
TEST_PATTERN = re.compile(tolerant(TEST))
for spelling in ("الاختبار", "الإختبار", "ألاختبار"):
    assert TEST_PATTERN.fullmatch(spelling)
assert not TEST_PATTERN.fullmatch("الاخبار")      # al-akhbar, "the news": a letter missing
SCHOOL = re.compile(tolerant("مدرسة"))
assert SCHOOL.fullmatch("مدرسه") and SCHOOL.fullmatch("مدرسة")
# The text is not changed: the match is the user's own spelling.
assert TEST_PATTERN.search("موعد الإختبار امتى").group() == "الإختبار"
# Known failure: a class cannot add a missing hamza seat or a dropped letter.
assert not TEST_PATTERN.fullmatch("الاختبر")
# The same pattern also accepts a form no one writes; harmless for search.
assert TEST_PATTERN.fullmatch("آلآختبآر")


# --- W3. One group, many forms: optional article and plural. -----------------------
EXAM_WRONG = re.compile(r"ال?امتحان")                 # ? binds to the lam only
EXAM_FORMS = re.compile(r"(?:ال)?امتحان(?:ات)?")      # article and plural as groups
EXAM_WORD = re.compile(r"\b[وف]?(?:ال)?امتحان(?:ات)?\b")

assert EXAM_WRONG.fullmatch("الامتحان")              # al-imtihan: fine
assert not EXAM_WRONG.fullmatch("امتحان")            # bare imtihan: rejected!
assert EXAM_WRONG.fullmatch("اامتحان")               # a typo with two alefs: accepted
for form in ("امتحان", "الامتحان", "امتحانات", "الامتحانات"):
    assert EXAM_FORMS.fullmatch(form)
assert EXAM_WORD.search("والامتحانات امتى؟").group() == "والامتحانات"
# Known failure: the dual (imtihanan / imtihanayn) and an attached pronoun are not listed.
assert EXAM_WORD.search("امتحانين") is None
assert EXAM_WORD.search("امتحاني") is None          # imtihani, "my exam"


# --- W4. Egyptian mobile numbers: order the policies. ------------------------------
MOBILE = re.compile(r"\b01[0125]\d{8}\b")
SEPARATORS = re.compile(r"(?<=\d)[\s-](?=\d)")      # a space or hyphen between digits


def find_mobiles(text):
    text = SEPARATORS.sub("", to_ascii_digits(text))
    return MOBILE.findall(text)


ASCII_MSG = "رقمي 01012345678"
INDIC_MSG = "رقمي ٠١٠١٢٣٤٥٦٧٨"
SPACED_MSG = "كلمني على 0122 345 6789"
assert MOBILE.findall(ASCII_MSG) == ["01012345678"]
assert MOBILE.findall(INDIC_MSG) == []              # \d would match, but 0, 1, [0125] are ASCII
assert MOBILE.findall(to_ascii_digits(INDIC_MSG)) == ["01012345678"]   # N5 first
assert MOBILE.findall(SPACED_MSG) == []
assert find_mobiles(SPACED_MSG) == ["01223456789"]
assert find_mobiles("الرقم 01312345678") == []        # 013 is not a mobile prefix
assert find_mobiles("ID 2010123456789") == []         # \b: inside a longer number
# Known failure: the international form +20 drops the leading 0.
assert find_mobiles("+201012345678") == []
# Known failure: the separator rule glues a neighbouring number on.
assert find_mobiles("الغرفة 3 01012345678") == []


# --- W5. Times with Arabic AM/PM letters: capture, and a boundary after one letter. -
TIME = re.compile(r"(\d{1,2}):(\d{2})(?:\s*([صم])\b)?")
TIME_NO_B = re.compile(r"(\d{1,2}):(\d{2})(?:\s*([صم]))?")

assert TIME.findall("المحاضرة الساعة ١٠:٣٠ ص") == [("١٠", "٣٠", "ص")]
assert TIME.findall("السكشن ١:١٥ م") == [("١", "١٥", "م")]
assert TIME_NO_B.findall("الساعة ٩:٠٠ مدرج ٥") == [("٩", "٠٠", "م")]   # m of madrag!
assert TIME.findall("الساعة ٩:٠٠ مدرج ٥") == [("٩", "٠٠", "")]         # \b refuses it
# Known failure: the full word "masa2an" (evening) is not read as PM.
assert TIME.findall("٧:٠٠ مساءً") == [("٧", "٠٠", "")]


def to_24h(hour, minute, half):
    h = int(to_ascii_digits(hour)) % 12 + (12 if half == "م" else 0)
    return f"{h:02d}:{to_ascii_digits(minute)}"


assert to_24h("١٠", "٣٠", "ص") == "10:30"
assert to_24h("١", "١٥", "م") == "13:15"
assert to_24h("١٢", "٠٠", "ص") == "00:00"


# --- W6. Is it a question? Two signals, one router rule. ---------------------------
Q_MARK = re.compile(r"[?؟]\s*$")
Q_WORD = re.compile(r"^\s*(?:متى|امتى|فين|اين|ازاي|كيف|هل)\b")


def is_question(text):
    text = normalize_alef(text)      # N3 first, so one alef form is enough in Q_WORD
    return bool(Q_MARK.search(text) or Q_WORD.search(text))


QUESTIONS = {
    "امتى الامتحان": True,          # Egyptian question word, no mark
    "الامتحان امتى؟": True,         # Arabic question mark at the end
    "إمتى النتيجة": True,           # hamza spelling: N3 makes it امتى
    "هل في محاضرة بكرة": True,      # hal, a yes/no question
    "المحاضرة اتلغت.": False,       # a statement
    "عايز اعرف ميعاد الامتحان": False,   # known failure: an indirect question
}
assert {m: is_question(m) for m in QUESTIONS} == QUESTIONS
assert not Q_MARK.search("امتى الامتحان")    # the mark alone misses it
assert not Q_WORD.search("متىن")     # \b: not the start of a longer word
assert is_question("أين القاعة")                 # N3 makes it اين
# N4 turns ى into ي: write the pattern in the spelling the normaliser produces.
assert not Q_WORD.search(normalize_ya_ta(normalize_alef("إمتى النتيجة")))
assert re.search(r"^(?:متي|امتي)\b", normalize_ya_ta(normalize_alef("إمتى النتيجة")))


# --- The "Pause, predict" activity: one answer per item. ---------------------------
assert MISH_CLITIC.findall("فمش هاجي بكرة") == ["فمش"]          # a. fa-mish: so not
assert MISH_CLITIC.findall("المشكلة اتحلت") == []                # b. el-mushkila
assert EXAM_WORD.findall("امتحانين في يوم واحد") == []           # c. the dual: missed
assert EXAM_WORD.findall("فالامتحانات") == ["فالامتحانات"]      # d. fa + al + plural
assert re.fullmatch(tolerant("مدرسة"), "مدرسه")                   # e. taa written as haa
assert TIME.findall("الساعة ١١:٠٠ م") == [("١١", "٠٠", "م")]     # f. ...
assert to_24h("١١", "٠٠", "م") == "23:00"                        #    ... is 23:00
assert find_mobiles("٠١٥٥١٢٣٤٥٦٧") == ["01551234567"]             # g. 015 is a prefix
assert is_question("فين القاعة") and not is_question("القاعة فين")  # h. word at the end

# --- Exercise answers E4 and E5. ---------------------------------------------------

TIME_WORDS = re.compile(r"(\d{1,2}):(\d{2})(?:\s*(صباحا|مساء|[صم])\b)?")
TIME_WORDS_LETTER_FIRST = re.compile(r"(\d{1,2}):(\d{2})(?:\s*([صم]|صباحا|مساء)\b)?")
for pattern in (TIME_WORDS, TIME_WORDS_LETTER_FIRST):       # order does not matter: \b backtracks
    assert pattern.findall(remove_diacritics("٧:٠٠ مساءً")) == [("٧", "٠٠", "مساء")]
    assert pattern.findall("١٠:٣٠ ص") == [("١٠", "٣٠", "ص")]
    assert pattern.findall("الساعة ٩:٠٠ مدرج ٥") == [("٩", "٠٠", "")]
    assert pattern.findall("٧:٠٠ صباحًا") == [("٧", "٠٠", "")]      # the mark sits inside the word
    assert pattern.findall(remove_diacritics("٧:٠٠ صباحًا")) == [("٧", "٠٠", "صباحا")]
    assert pattern.findall("٧:٠٠ مساءً") == [("٧", "٠٠", "مساء")]  # final mark: \b still holds
Q_END = re.compile(r"\b(?:متى|امتى|فين|ازاي)\s*[?؟]?\s*$")
Q_END_NO_B = re.compile(r"(?:متى|امتى|فين|ازاي)\s*[?؟]?\s*$")
assert Q_END.search(normalize_alef("القاعة فين"))
assert Q_END_NO_B.search("كلمت الموظفين")                  # W1 again: fin inside a word
assert not Q_END.search("كلمت الموظفين")
assert Q_END.search("مش عارف امتى")                       # a statement, wrongly accepted

# E6: a lookbehind, and a substitution with two groups.
assert re.findall(r"(?<=المبلغ )\d+", "رقم 4589 والمبلغ 300") == ["300"]
CODE = re.compile(r"\b([A-Z]{2,4})\s?(\d{3})\b")
assert CODE.sub(r"<\1\2>", "CS 120 and CS120") == "<CS120> and <CS120>"
try:
    re.compile(r"(?<=المبلغ\s*)\d+")
    raise AssertionError("variable-width lookbehind should fail")
except re.error:
    pass
assert re.findall(r"المبلغ\s*(\d+)", "والمبلغ   300") == ["300"]

if __name__ == "__main__":
    print("W1 mish:", [bool(MISH_CLITIC.search(m)) for m in (PROBLEM, PROJECT, NEGATED, AND_NOT)])
    print("W2 tolerant:", tolerant(TEST))
    print("W4 mobiles:", find_mobiles(INDIC_MSG), find_mobiles(SPACED_MSG))
    print("W5 times:", TIME.findall("المحاضرة الساعة ١٠:٣٠ ص، والسكشن ١:١٥ م"))
    print("all Arabic pattern checks passed")
