"""Chapter 2: regular expressions as written policies on Arabic text.

Run: python3 examples/ch02/regex_policies.py
Every number the chapter prints is asserted here.
"""
import re
from span_scoring import extraction_counts

DIACRITICS = re.compile(r"[\u064B-\u0652\u0670]")
TATWEEL = re.compile(r"\u0640")
ALEF_VARIANTS = re.compile(r"[\u0622\u0623\u0625\u0671]")

def remove_diacritics(text):      # N1
    return DIACRITICS.sub("", text)

def remove_tatweel(text):         # N2
    return TATWEEL.sub("", text)

def normalize_alef(text):         # N3
    return ALEF_VARIANTS.sub("\u0627", text)


# --- Python's built-in classes are Unicode-aware -----------------------------
VOCALISED = "\u064a\u064e\u062f\u0652\u0631\u064f\u0633\u064f\u0648\u0646\u064e"  # yadrusuna
assert len(re.findall(r"\w+", VOCALISED)) == 5          # every mark ends a match
assert re.findall(r"\w+", remove_diacritics(VOCALISED)) == ["\u064a\u062f\u0631\u0633\u0648\u0646"]
assert re.findall(r"\d+", "room 204 / ٢٠٤") == ["204", "٢٠٤"]

# --- Evaluate a pattern like any classifier (Example 2.3) --------------------
COURSE_CODE = re.compile(r"\b[A-Z]{2,4}\s?[0-9]{3}\b")
MESSAGES = [  # (message, true course codes in it)
    ("Registered CS101 and MATH 205", ["CS101", "MATH 205"]),
    ("Is PHYS 110 full? Also CHEM 120", ["PHYS 110", "CHEM 120"]),
    ("Drop BIO 101, add ENG 102", ["BIO 101", "ENG 102"]),
    ("CS201 lab moved to ROOM 204", ["CS201"]),
    ("STAT 230 exam in HALL 110", ["STAT 230"]),
    ("Grades for ART 150 and HIST 210", ["ART 150", "HIST 210"]),
    ("NLP 301 needs CS 210 first", ["NLP 301", "CS 210"]),
    ("Waitlist for ECON 101 and LAW 220", ["ECON 101", "LAW 220"]),
    ("Clash between GEO 110 and MUS 140", ["GEO 110", "MUS 140"]),
    ("cs101 portal is down", ["cs101"]),
    ("Missing grade in CS-101", ["CS-101"]),
    ("Room change for CS ١٢٠", ["CS ١٢٠"]),
    ("MATH ٢٠٥ timetable", ["MATH ٢٠٥"]),
]
true_spans = [c for _, codes in MESSAGES for c in codes]
returned = [m for text, _ in MESSAGES for m in COURSE_CODE.findall(text)]
n_true, n_returned, n_correct = extraction_counts(COURSE_CODE, MESSAGES)
assert (n_true, n_returned, n_correct) == (20, 18, 16)
assert (len(true_spans), len(returned)) == (n_true, n_returned)
precision, recall = n_correct / n_returned, n_correct / n_true
assert round(precision, 3) == 0.889 and recall == 0.80
false_positives = sorted(set(returned) - set(true_spans))
assert false_positives == ["HALL 110", "ROOM 204"]

# --- Operator precedence: alternation binds last ------------------------------
AL, KITAB, KUTUB = "\u0627\u0644", "\u0643\u062a\u0627\u0628", "\u0643\u062a\u0628"
WITHOUT_PARENS = re.compile(AL + KITAB + "|" + KUTUB)        # al-kitab | kutub
WITH_PARENS = re.compile(AL + "(?:" + KITAB + "|" + KUTUB + ")")  # al-(kitab|kutub)
assert WITHOUT_PARENS.fullmatch(KUTUB) and not WITHOUT_PARENS.fullmatch(AL + KUTUB)
assert WITH_PARENS.fullmatch(AL + KUTUB) and not WITH_PARENS.fullmatch(KUTUB)

# --- Substitution, capture, and lookaround -------------------------------------
NUMBER = re.compile(r"(\d+)")
def mark_numbers(text):                    # s/(\d+)/<\1>/
    return NUMBER.sub(r"<\1>", text)

ELONGATION = re.compile(r"(\w)\1{2,}")     # one word character typed 3+ times
def collapse_elongation(text):
    return ELONGATION.sub(r"\1", text)

ARTICLE = re.compile(r"^\u0627\u0644(?=[\u0621-\u063a\u0641-\u064a]{3})")  # al- + 3 letters
def strip_article(word):
    return ARTICLE.sub("", word)

AFTER_RAQAM = re.compile(r"(?<=\u0631\u0642\u0645 )\d+")       # digits after "raqam "


assert mark_numbers("طلب 35") == "طلب <35>"                     # talab 35
assert collapse_elongation("جمييييل") == "جميل"                  # gamiiiil -> gamil
assert collapse_elongation("gamiiiil") == "gamil"
assert collapse_elongation("ههههههه") == "ه"                     # laughter: a known loss
assert collapse_elongation("gameel") == "gameel"                 # two letters are kept
assert strip_article("الطلاب") == "طلاب"                         # al-tullab -> tullab
assert strip_article("الله") == "الله"                           # only two letters follow
assert AFTER_RAQAM.findall("رقم 4589 والمبلغ 300") == ["4589"]

# --- Refining a price pattern (Example: Egyptian-pound fees) ------------------
FEES = [  # (message, true amounts)
    ("الرسوم 150.50 جنيه", ["150.50"]),
    ("رسوم الكارنيه 75 جنيه", ["75"]),
    ("EGP 1250 for the summer course", ["1250"]),
    ("دفعت 300 ج.م امبارح", ["300"]),
    ("the fee is ١٢٠ جنيه", ["١٢٠"]),
    ("الامتحان يوم 12.05 الساعة 10", []),
    ("update the app to version 2.10", []),
    ("غرامة التأخير 20.00 جنيه", ["20.00"]),
    ("رقم الطلب 4589", []),
    ("EGP ٤٥٠ رسوم إعادة القيد", ["٤٥٠"]),
    ("EGP 1,250 للبرنامج الصيفي", ["1,250"]),
]
CURRENCY = r"(?:\u062c\u0646\u064a\u0647|\u062c\.\u0645)"        # gineh | g.m.
PRICE_V1 = re.compile(r"[0-9]+\.[0-9]{2}")
PRICE_V2 = re.compile(r"EGP ?([0-9]+(?:\.[0-9]{2})?)\b|\b([0-9]+(?:\.[0-9]{2})?) ?" + CURRENCY)
PRICE_V3 = re.compile(r"EGP ?(\d+(?:\.\d{2})?)\b|\b(\d+(?:\.\d{2})?) ?" + CURRENCY)

def amounts(pattern, text):
    found = []
    for m in pattern.finditer(text):
        groups = [g for g in m.groups() if g] if m.groups() else []
        found.append(groups[0] if groups else m.group())
    return found

def score(pattern):
    return extraction_counts(pattern, FEES)

assert score(PRICE_V1) == (8, 4, 2)        # P .50   R .25: dates, versions; misses whole pounds
assert score(PRICE_V2) == (8, 6, 5)        # P .833  R .625: misses Arabic-Indic digits
assert score(PRICE_V3) == (8, 8, 7)        # P .875  R .875: still breaks on "1,250"
assert amounts(PRICE_V3, "EGP 1,250 للبرنامج الصيفي") == ["1"]

if __name__ == "__main__":
    print(f"precision {precision:.3f}  recall {recall:.2f}")
    print("false positives:", false_positives)
    print("false negatives:", [c for c in true_spans if c not in returned])

# The matching operation and Unicode classes are part of the policy.
assert re.search(r"[0-9]{3}", "1234").group() == "123"
assert re.fullmatch(r"[0-9]{3}", "1234") is None
assert re.fullmatch(r"[0-9]{3}", "123") is not None
assert re.fullmatch(r"\w+", "1000_") is not None
assert collapse_elongation("1000") == "10"
assert re.search(r"123$", "123\n") is not None
assert re.fullmatch(r"123", "123\n") is None

# --- Figure 2.3: the marks are stored as code points --------------------------
import unicodedata  # noqa: E402
assert len(VOCALISED) == 11                                # 6 letters, each mark right after its letter
assert [unicodedata.category(c) for c in VOCALISED].count("Mn") == 5

# --- Decomposed hamza: N1 and N3 expect one code point per letter -------------
DECOMPOSED = unicodedata.normalize("NFD", "أحمد")           # alef + U+0654 + ...
assert DECOMPOSED[:2] == "أ"
assert normalize_alef(remove_diacritics(DECOMPOSED)) != "احمد"   # the pair survives
assert normalize_alef(unicodedata.normalize("NFC", DECOMPOSED)) == "احمد"
