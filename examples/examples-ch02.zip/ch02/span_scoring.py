"""Exact occurrence scoring for Chapter 2's constructed extraction fixtures.

Reference strings must appear in message order. Real annotation tools should
store offsets directly; this helper locates the supplied teaching references.
"""


def reference_spans(text, references):
    spans, cursor = set(), 0
    for value in references:
        start = text.index(value, cursor)
        cursor = start + len(value)
        spans.add((start, cursor))
    return spans


def extraction_counts(pattern, messages):
    """Return reference, predicted, correct counts using exact message offsets.

    For the price fixture the first participating capture is the amount;
    patterns with no captures return the entire match (the course-code case).
    """
    totals = [0, 0, 0]
    for text, references in messages:
        gold = reference_spans(text, references)
        predicted = set()
        for match in pattern.finditer(text):
            group = next((i for i, value in enumerate(match.groups(), 1)
                          if value), 0)
            predicted.add(match.span(group))
        for i, value in enumerate((len(gold), len(predicted), len(gold & predicted))):
            totals[i] += value
    return tuple(totals)


if __name__ == "__main__":
    import re

    # Matching the same string in the wrong occurrence earns no credit.
    assert extraction_counts(re.compile(r"CS101$"),
                             [("CS101 then CS101", ["CS101"])]) == (1, 1, 0)
    assert extraction_counts(re.compile(r"CS101"),
                             [("CS101 CS101", ["CS101", "CS101"])]) == (2, 2, 2)
    # A partial amount is both a false positive and a missed full reference.
    assert extraction_counts(re.compile(r"EGP (\d+)"),
                             [("EGP 1,250", ["1,250"])]) == (1, 1, 0)
    # Non-overlapping extraction can lose recall after an alternative is added.
    fixture = [("CS101", ["CS101"])]
    assert extraction_counts(re.compile(r"CS101"), fixture) == (1, 1, 1)
    assert extraction_counts(re.compile(r"cs|CS101", re.I), fixture) == (1, 1, 0)
