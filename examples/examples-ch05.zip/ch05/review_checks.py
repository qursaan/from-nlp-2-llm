"""Chapter 5: numbers in the roadmap, the comics, the unknown-word example, E1 and E5.

Run: python3 examples/ch05/review_checks.py
"""
import math
from collections import Counter

CORPUS = ["I love natural language processing", "I love deep learning",
          "deep learning needs data", "natural language processing needs data",
          "students love deep learning", "I study natural language processing"]
SENTS = [s.lower().split() for s in CORPUS]
VOCAB = sorted({w for s in SENTS for w in s})
PAIRS = Counter((a, b) for s in SENTS for a, b in zip(s, s[1:]))
OUT = Counter(a for s in SENTS for a in s[:-1])
assert len(VOCAB) == 11 and sum(map(len, SENTS)) == 27

# Roadmap stop 1 and the zero-count comic: love is never followed by data.
assert PAIRS["i", "love"] / OUT["i"] == 2 / 3
assert OUT["love"] == 3 and PAIRS["love", "data"] == 0
assert math.isclose((PAIRS["love", "data"] + 1) / (OUT["love"] + len(VOCAB)), 1 / 14)

# Unknown-word example and E5: train on two sentences, score "i love music".
TRAIN = [["i", "love", "learning"], ["i", "love", "data"]]
SUPPORT = ["i", "love", "learning", "data", "</s>", "<unk>"]          # V = 6
padded = [["<s>"] + s + ["</s>"] for s in TRAIN]
C = Counter((a, b) for s in padded for a, b in zip(s, s[1:]))
OUTC = Counter(a for s in padded for a in s[:-1])


def add_one(a, b):
    return (C[a, b] + 1) / (OUTC[a] + len(SUPPORT))


test = ["<s>", "i", "love", "<unk>", "</s>"]                           # music -> <unk>
probs = [add_one(a, b) for a, b in zip(test, test[1:])]
assert probs == [3 / 8, 3 / 8, 1 / 8, 1 / 6]
assert math.isclose(math.prod(probs), 9 / 3072) and round(math.log(math.prod(probs)), 2) == -5.83

# E5: two more held-out sentences under the same model.
def score(words):
    seq = ["<s>"] + [w if w in SUPPORT else "<unk>" for w in words] + ["</s>"]
    return math.prod(add_one(a, b) for a, b in zip(seq, seq[1:]))


assert math.isclose(score("i love data".split()), 9 / 896)
assert math.isclose(score("i like data".split()), 1 / 448)

# E1: padded trigram windows for "i love deep learning" (L + 1 = 5).
s = ["<s>", "<s>", "i", "love", "deep", "learning", "</s>"]
assert len([s[i:i + 3] for i in range(len(s) - 2)]) == 5

if __name__ == "__main__":
    print("Chapter 5 review checks pass.")
