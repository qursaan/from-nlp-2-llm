"""Chapter 5: sentence-bounded counts and inverse-CDF generation.

Seeded generation illustrates the fitted distribution, not held-out quality.
"""
from collections import Counter, defaultdict
import math
import random


def fit(sentences):
    counts = defaultdict(Counter)
    for sentence in sentences:
        tokens = ["<s>", *sentence, "</s>"]
        for a, b in zip(tokens, tokens[1:]):
            counts[a][b] += 1
    return {a: {b: row[b] / sum(row.values()) for b in sorted(row)}
            for a, row in counts.items()}


def draw(row, u):
    if not 0 <= u < 1:
        raise ValueError("draw must lie in [0, 1)")
    if not row or any(not math.isfinite(p) or p < 0 for p in row.values()):
        raise ValueError("invalid probability row")
    if not math.isclose(math.fsum(row.values()), 1):
        raise ValueError("probability row must sum to one")
    cumulative = 0.0
    for token, probability in row.items():
        cumulative += probability
        if u < cumulative:
            return token
    return next(token for token, p in reversed(list(row.items())) if p > 0)


def generate(rows, rng, max_targets=20):
    if max_targets < 1:
        raise ValueError("generation needs a positive target budget")
    context, output = "<s>", []
    for _ in range(max_targets):
        token = draw(rows[context], rng.random())
        output.append(token)
        if token == "</s>":
            return output, "end"
        context = token
    return output, "budget"


ROWS = fit(["i love learning".split(), "i love data".split()])
assert ROWS["love"] == {"data": .5, "learning": .5}
assert all(math.isclose(sum(row.values()), 1) for row in ROWS.values())
assert "<s>" not in {w for row in ROWS.values() for w in row}
assert draw(ROWS["love"], 0) == "data"
assert draw(ROWS["love"], .4999) == "data"
assert draw(ROWS["love"], .5) == "learning"
assert draw({"impossible": 0, "certain": 1}, 0) == "certain"
assert generate(ROWS, random.Random(7)) == (["i", "love", "learning", "</s>"], "end")
assert generate(ROWS, random.Random(7), 2) == (["i", "love"], "budget")
assert generate({"<s>": {"a": 1}, "a": {"a": 1}}, random.Random(0), 3)[1] == "budget"
assert fit([[]]) == {"<s>": {"</s>": 1}}
for invalid in ({}, {"a": .75, "b": .25, "c": .25}, {"a": -1, "b": 2}):
    try:
        draw(invalid, .5)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid sampling row accepted")
if __name__ == "__main__":
    print(ROWS)
    print(generate(ROWS, random.Random(7)))
