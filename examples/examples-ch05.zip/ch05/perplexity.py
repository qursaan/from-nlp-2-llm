"""Chapter 5: the perplexity example (ex:ppl-basic) and exercise E4.

Run: python3 examples/ch05/perplexity.py
"""
import math

# Example: P("i love learning" + </s>) = 1/2 over four targets.
ppl = lambda probs: math.exp(-sum(map(math.log, probs)) / len(probs))
assert round(ppl([1, 1, 0.5, 1]), 2) == 1.19
assert round(0.5 ** (-1 / 3), 2) == 1.26                 # end marker omitted
assert round(ppl([0.5, 0.25, 0.25, 0.125]), 6) == 4.0    # E4
assert round(math.log(4), 3) == 1.386
