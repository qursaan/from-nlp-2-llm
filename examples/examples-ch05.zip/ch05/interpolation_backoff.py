"""Chapter 5: normalized mixtures, residual-mass backoff, held-out weights.

These illustrative rows are fixed training estimates, not a Katz estimator.
"""
import math

SUPPORT = ("A", "B", "C")
HIGH = {"A": .75, "B": .25, "C": 0.0}
LOW = {"A": .5, "B": .25, "C": .25}


def mixture(weight):
    if not 0 <= weight <= 1:
        raise ValueError("mixture weight must lie in [0, 1]")
    return {w: weight * HIGH[w] + (1 - weight) * LOW[w] for w in SUPPORT}


def mean_loss(row, targets):
    if not targets:
        raise ValueError("at least one scored target is required")
    if any(row[w] == 0 for w in targets):
        return math.inf
    return -math.fsum(math.log(row[w]) for w in targets) / len(targets)


RAW_FALLBACK = {w: HIGH[w] if HIGH[w] else LOW[w] for w in SUPPORT}
BACKOFF = {"A": .6, "B": .2}  # deliberately discounted observed mass: .8
unseen = [w for w in SUPPORT if w not in BACKOFF]
residual = 1 - math.fsum(BACKOFF.values())
lower_unseen_mass = math.fsum(LOW[w] for w in unseen)
BACKOFF.update({w: residual * LOW[w] / lower_unseen_mass for w in unseen})
assert math.isclose(sum(RAW_FALLBACK.values()), 1.25)
assert math.isclose(sum(BACKOFF.values()), 1)
assert math.isclose(BACKOFF["C"], .2)
assert mixture(.5) == {"A": .625, "B": .25, "C": .125}
assert all(math.isclose(sum(mixture(w).values()), 1) for w in (0, .25, .5, .75, 1))

DEV_TARGETS = ["A", "A", "A", "C"]
GRID = (0, .25, .5, .75, 1)
LOSSES = {w: mean_loss(mixture(w), DEV_TARGETS) for w in GRID}
SELECTED = min(GRID, key=lambda w: LOSSES[w])
assert SELECTED == .25
assert LOSSES[1] == math.inf
assert math.isclose(mixture(SELECTED)["A"], .5625)
assert math.isclose(mixture(SELECTED)["C"], .1875)
assert math.isclose(math.exp(mean_loss({"red": .8, "blue": .1, "green": .1},
                                      ["red"] * 4 + ["blue"])), 1.894645708137997)
if __name__ == "__main__":
    print("naive fallback sum:", sum(RAW_FALLBACK.values()))
    print("normalized backoff:", BACKOFF)
    print("dev mean losses:", LOSSES)
    print("selected weight:", SELECTED)
