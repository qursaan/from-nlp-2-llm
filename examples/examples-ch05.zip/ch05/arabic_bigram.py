"""Chapter 5: the three-request Arabic bigram example (fig:arabic-ngrams, ex:arabic-bigram).

Run: python3 examples/ch05/arabic_bigram.py
"""
import math
from collections import Counter
from fractions import Fraction

BOS, EOS = "<s>", "</s>"
URID, TAJIL, EXAM, SUBMISSION, MATA = (
    "أريد", "تأجيل",
    "الاختبار",
    "التسليم", "متى")
CORPUS = [[URID, TAJIL, EXAM], [URID, TAJIL, SUBMISSION], [MATA, EXAM]]

counts, outgoing, targets = Counter(), Counter(), set()
for sentence in CORPUS:
    padded = [BOS] + sentence + [EOS]
    for a, b in zip(padded, padded[1:]):
        counts[a, b] += 1
        outgoing[a] += 1
        targets.add(b)
V = len(targets)                     # five words and </s>; <s> is never a target
assert V == 6


def mle(b, a):
    return Fraction(counts[a, b], outgoing[a])


def add_one(b, a):
    return Fraction(counts[a, b] + 1, outgoing[a] + V)


def prob(sentence, p):
    padded = [BOS] + sentence + [EOS]
    return math.prod(p(b, a) for a, b in zip(padded, padded[1:]))


assert prob(CORPUS[0], mle) == Fraction(1, 3)
assert round(3 ** 0.25, 2) == 1.32                      # perplexity over 4 targets
unseen = [MATA, TAJIL, EXAM]
assert prob(unseen, mle) == 0
assert prob(unseen, add_one) == Fraction(1, 336)
assert round(math.log(1 / 336), 2) == -5.82
assert prob(CORPUS[1], mle) == Fraction(1, 3)            # exercise E3
assert prob(CORPUS[1], add_one) == Fraction(1, 112)

if __name__ == "__main__":
    print(f"{'context':>10} {'next':>10}  C(a,b)  Cout  MLE   add-one")
    for (a, b), c in sorted(counts.items()):
        print(f"{a:>10} {b:>10}  {c:>6}  {outgoing[a]:>4}  {str(mle(b, a)):<5} {add_one(b, a)}")
    print("P(unseen request), add-one:", prob(unseen, add_one))
