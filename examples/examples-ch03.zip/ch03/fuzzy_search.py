"""Chapter 3: Sanad's "did you mean?" search over a small keyword lexicon.

Queries are normalised (N3, N4) and compared with every lexicon entry by unit-cost
edit distance; the nearest entry is suggested only if it is within the threshold.
Run: python3 examples/ch03/fuzzy_search.py
"""

from edit_distance import distance_table

# Help-desk keywords, stored already normalised (taa marbuta written as haa).
LEXICON = ["محاضره", "امتحان", "تسجيل", "منحه", "مكتبه", "نتيجه", "جدول", "غياب"]
THRESHOLD = 1


def normalise(word):
    for alef in "آأإٱ":
        word = word.replace(alef, "ا")
    return word.replace("ى", "ي").replace("ة", "ه")


def strip_article(word):
    return word[2:] if word.startswith("ال") and len(word) - 2 >= 3 else word


def distance(a, b):
    return distance_table(a, b)[-1][-1]


def suggest(query, threshold=THRESHOLD, article=False):
    """Return (nearest entry, distance), or (None, distance) if it is too far."""
    q = normalise(query)
    if article:
        q = strip_article(q)
    best = min(LEXICON, key=lambda entry: (distance(q, entry), LEXICON.index(entry)))
    d = distance(q, best)
    return (best if d <= threshold else None), d


# 1. A dropped long vowel: one deletion away, suggested.
assert suggest("محضرة") == ("محاضره", 1)            # mohadra -> mohadara (lecture)
# 2. A dropped alef in the stem: one edit, suggested.
assert suggest("امتحن") == ("امتحان", 1)             # imtihn -> imtihan (exam)
# 3. The article adds two letters, so the right word is beyond the threshold ...
assert suggest("التسجيل") == (None, 2)               # el-tasgil (the registration)
# ... until the article is removed first: normalise what you can list.
assert suggest("التسجيل", article=True) == ("تسجيل", 0)
# 4. A real word the lexicon lacks: "office" is one letter from "library".
assert suggest("مكتب") == ("مكتبه", 1)               # maktab -> maktaba: wrong!
# Raising the threshold does not fix 4; it only lets more far words through.
assert suggest("التسجيل", threshold=2) == ("تسجيل", 2)
assert suggest("نتايج", threshold=2) == ("نتيجه", 2)  # nata2ig, plural of "result"
# The nearest entry for "office" is not a tie: the runner-up is 2 edits further.
assert sorted(distance("مكتب", e) for e in LEXICON)[:2] == [1, 3]

# Exercise E6: short real words are one edit from a lexicon entry, so they get "corrected".
assert suggest("جدل") == ("جدول", 1)                 # gadal, "argument" -> gadwal
assert suggest("غيب") == ("غياب", 1)                 # ghayb, "the unseen" -> ghiyab


def suggest_by_length(query):
    """Allow one edit only for queries of five letters or more."""
    return suggest(query, threshold=1 if len(query) >= 5 else 0)


assert [suggest_by_length(q)[0] for q in ("محضرة", "امتحن", "مكتب", "جدل", "غيب")] \
    == ["محاضره", "امتحان", None, None, None]

# Worksheet 5, task 6: predict, then check.
assert suggest("نتيجة") == ("نتيجه", 0)              # N4 alone repairs it
assert suggest("جداول") == ("جدول", 1)               # plural "timetables": a fair repair
assert suggest("غائب") == (None, 2)                  # gha2ib, "absent": too far
assert suggest("تسجبل") == ("تسجيل", 1)              # a dotted-letter typo
assert suggest("مكتبتي") == (None, 2)                # "my library": the suffix blocks it

if __name__ == "__main__":
    for q in ("محضرة", "امتحن", "التسجيل", "مكتب"):
        print(q, suggest(q), suggest(q, article=True))
    print("all fuzzy-search checks passed")
