"""Independent exhaustive path checks for the chapter's weighted recurrence."""
from functools import lru_cache
from itertools import product

from edit_distance import distance_table, align
from weighted_edit_distance import weighted_table, spelling_change


def path_minimum(source, target, delete, insert, substitute):
    # Enumerate legal alignment paths forward, independently of the table fill.
    @lru_cache(None)
    def visit(i, j):
        if i == len(source) and j == len(target):
            return 0.0
        paths = []
        if i < len(source):
            paths.append(delete(source[i]) + visit(i + 1, j))
        if j < len(target):
            paths.append(insert(target[j]) + visit(i, j + 1))
        if i < len(source) and j < len(target):
            change = 0 if source[i] == target[j] else substitute(source[i], target[j])
            paths.append(change + visit(i + 1, j + 1))
        return min(paths)
    return visit(0, 0)


strings = [""] + ["".join(p) for n in (1, 2) for p in product("ab", repeat=n)]
delete = lambda x: 0.5 if x == "a" else 2.0
insert = lambda y: 1.5 if y == "a" else 0.25
substitute = lambda x, y: 0.75 if (x, y) == ("a", "b") else 3.0
for a, b in product(strings, repeat=2):
    assert weighted_table(a, b, delete, insert, substitute)[-1][-1] == path_minimum(
        a, b, delete, insert, substitute)
    for c in (1, 2):
        assert weighted_table(a, b, lambda x: 1, lambda y: 1,
                              lambda x, y: c) == distance_table(a, b, c)

assert weighted_table("ab", "", delete, insert, substitute)[-1][0] == 2.5
assert weighted_table("", "ab", delete, insert, substitute)[0][-1] == 1.75
assert weighted_table("مدرسة", "مدرسه", lambda x: 1, lambda y: 1, spelling_change)[-1][-1] == 0.25
assert weighted_table("مدرسه", "مدرسة", lambda x: 1, lambda y: 1, spelling_change)[-1][-1] == 1.0
assert weighted_table("مدرسة", "مدرسب", lambda x: 1, lambda y: 1, spelling_change)[-1][-1] == 1.0
assert weighted_table("a", "b", lambda x: 1, lambda y: 1, lambda x, y: 3)[-1][-1] == 2
for invalid in (-1, float("inf"), float("nan")):
    try:
        weighted_table("a", "", lambda x: invalid, insert, substitute)
    except ValueError:
        pass
    else:
        raise AssertionError("invalid cost accepted")

assert distance_table("intention", "execution", 1)[-1][-1] == 5
assert distance_table("intention", "execution", 2)[-1][-1] == 8
assert align("intention", "execution", 2)[2] == "DSSMISMMMM"
assert {s: distance_table("graffe", s)[-1][-1] for s in ("graf", "graft", "grail", "giraffe")} == {
    "graf": 2, "graft": 2, "grail": 3, "giraffe": 1}
print("Weighted paths, boundaries, asymmetry, unit-cost parity, and lecture examples passed.")
