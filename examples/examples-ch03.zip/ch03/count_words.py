"""Chapter 3: a counting command is a tokenization policy (Example ex:count-policy).

Run: python3 examples/ch03/count_words.py
"""
import re
from collections import Counter

MESSAGE = "3ayez el-exam, can't find the Exam! امتحان؟"


def count_words(text, keep_apostrophe=False):
    """Lower-case, then keep runs of Unicode word characters (N1 first for Arabic marks)."""
    pattern = r"\w+(?:'\w+)?" if keep_apostrophe else r"\w+"
    return Counter(re.findall(pattern, text.lower()))


# The ASCII command of the chapter: tr -cs 'A-Za-z' '\n'
ascii_tokens = re.findall(r"[A-Za-z]+", MESSAGE)
assert ascii_tokens == ["ayez", "el", "exam", "can", "t", "find", "the", "Exam"]
assert (len(ascii_tokens), len(set(ascii_tokens))) == (8, 8)

unicode_counts = count_words(MESSAGE)
assert sum(unicode_counts.values()) == 9 and len(unicode_counts) == 8
assert unicode_counts["exam"] == 2 and unicode_counts["امتحان"] == 1 and "3ayez" in unicode_counts
assert unicode_counts["t"] == 1                       # the apostrophe still splits can't

contraction_counts = count_words(MESSAGE, keep_apostrophe=True)
assert sum(contraction_counts.values()) == 8 and len(contraction_counts) == 7
assert contraction_counts["can't"] == 1

# Worksheet 5, task 3: the ASCII command on a second message.
SHEET = "The exam's at 10. the EXAM room is 2B"
sheet_tokens = re.findall(r"[A-Za-z]+", SHEET)
assert sheet_tokens == ["The", "exam", "s", "at", "the", "EXAM", "room", "is", "B"]
assert (len(sheet_tokens), len(set(sheet_tokens))) == (9, 9)
assert len({t.lower() for t in sheet_tokens}) == 7

if __name__ == "__main__":
    print("ASCII:  ", ascii_tokens)
    print("Unicode:", dict(unicode_counts))
    print("Keep ': ", dict(contraction_counts))
