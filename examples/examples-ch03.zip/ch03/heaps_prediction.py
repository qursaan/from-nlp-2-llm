"""Chapter 3: predicting vocabulary growth with Heaps' law (Example ex:heaps-predict).

Run: python3 examples/ch03/heaps_prediction.py
The (N, V) points are the Lab 3 corpus counts printed in the chapter.
"""
import math

FIRST, LAST = (51, 36), (185, 105)          # after 10 and after 40 requests
BETA = math.log(LAST[1] / FIRST[1]) / math.log(LAST[0] / FIRST[0])
assert round(BETA, 2) == .83


def predict(n, beta, known=LAST):
    """V(n) = V(N0) * (n / N0) ** beta: the ratio form needs no k."""
    n0, v0 = known
    return v0 * (n / n0) ** beta


assert round(2 ** .83, 2) == 1.78                 # doubling the text
assert round(predict(370, .83)) == 187
assert round(predict(10_000, .83), -1) == 2880
assert round(predict(10_000, .70), -1) == 1710    # an assumed alternative exponent
assert round(predict(10_000, .70)) == 1715        # "about 1,715" in the chapter
assert round(10_000 / 185) == 54                  # "about 54 times"
assert round(predict(10_000, .83) - predict(10_000, .70), -1) == 1170

# The four corpus points (every tenth request): a least-squares line on log-log axes.
POINTS = [(51, 36), (101, 61), (149, 84), (185, 105)]
xs = [math.log(n) for n, _ in POINTS]
ys = [math.log(v) for _, v in POINTS]
mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
LSQ_BETA = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
assert round(LSQ_BETA, 2) == .82

# Exercise E7(a): the 20- and 40-request points give a different exponent.
BETA_20_40 = math.log(105 / 61) / math.log(185 / 101)
assert round(BETA_20_40, 2) == .90
assert round(predict(370, .90)) == 196

# The same points counted from the corpus, ten requests at a time (the vocabulary-growth comic):
# the last ten requests still bring 21 new types in 36 tokens.
import re
from pathlib import Path

CORPUS = Path(__file__).resolve().parents[2] / "labs" / "lab03" / "data" / "corpus_ar.txt"
MARKS = re.compile(r"[\u064B-\u0652\u0670\u0640]")
WORD = re.compile(r"[\u0621-\u063A\u0641-\u064A]+")
REQUESTS = [WORD.findall(MARKS.sub("", line)) for line in CORPUS.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.startswith("#")]
assert len(REQUESTS) == 40


def growth_by_tens():
    """(new tokens, new types, N, V) after each block of ten requests."""
    seen, n, rows = set(), 0, []
    for k in range(0, len(REQUESTS), 10):
        block = [t for r in REQUESTS[k:k + 10] for t in r]
        new = set(block) - seen
        seen |= new
        n += len(block)
        rows.append((len(block), len(new), n, len(seen)))
    return rows


GROWTH = growth_by_tens()
assert [(n, v) for _, _, n, v in GROWTH] == POINTS
assert [(t, v) for t, v, _, _ in GROWTH] == [(51, 36), (50, 25), (48, 23), (36, 21)]
assert round(21 / 36, 2) == .58

if __name__ == "__main__":
    for n in (370, 10_000):
        print(f"N={n:>6}: V≈{predict(n, .83):7.1f} (β=.83)  V≈{predict(n, .70):7.1f} (β=.70)")
