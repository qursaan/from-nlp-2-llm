"""Chapter 3: one mini-corpus counted under three tokenization policies.

The three messages ask when the exam is. The question "how many times do the
messages mention the exam?" has a different answer under each policy.
Run: python3 examples/ch03/policy_counts.py
"""

import re
from collections import Counter

CORPUS = [
    "امتحان الرياضة امتى؟",          # imtihan el-riyada imta? (the maths exam, when?)
    "الإمتحان إمتى؟",                # el-imtihan imta? (with hamza below)
    "والامتحان في القاعه ٢٠٤",       # wa-l-imtihan fi el-qa3a 204 (taa written as haa)
]

MARKS = re.compile(r"[ً-ْٰـ]")            # N1, N2
ALEF = re.compile(r"[آأإٱ]")              # N3
DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")            # N5
TOKEN = re.compile(r"[ء-ي]+|\d+")                    # Arabic words, digit runs
CLITICS = re.compile(r"^([وف]?)([بكل]?)((?:ال)?)")            # the N8 prefix pattern


def normalise(text):
    text = ALEF.sub("ا", MARKS.sub("", text))
    return text.replace("ى", "ي").replace("ة", "ه").translate(DIGITS)   # N4, N5


def split_clitics(word, min_stem=3):
    """N8, but keep each clitic as a token of its own instead of deleting it."""
    m = CLITICS.match(word)
    stem = word[m.end():]
    if m.end() == 0 or len(stem) < min_stem:
        return [word]
    return [part for part in m.groups() if part] + [stem]


def spaces(text):                       # P1: split on spaces, nothing else
    return text.split()


def normalised(text):                   # P2: N1-N5, then Arabic words and digit runs
    return TOKEN.findall(normalise(text))


def clitics_split(text):                # P3: P2, then N8 splits the clitics off
    return [part for word in normalised(text) for part in split_clitics(word)]


def counts(policy):
    tokens = [t for message in CORPUS for t in policy(message)]
    return len(tokens), Counter(tokens)


N1, C1 = counts(spaces)
N2, C2 = counts(normalised)
N3, C3 = counts(clitics_split)

# P1: every token is a different type; "imta?" carries its question mark.
assert (N1, len(C1)) == (9, 9)
assert "امتى؟" in C1 and "إمتى؟" in C1
# P2: the same 9 tokens, but the two spellings of "imta" merge into one type.
assert (N2, len(C2)) == (9, 8)
assert C2["امتي"] == 2 and C2["امتحان"] == 1
assert {"امتحان", "الامتحان", "والامتحان"} <= set(C2)   # still three exam types
# P3: 5 clitic tokens are added (4 al-, 1 wa-), and the exam stem is counted 3 times.
assert (N3, len(C3)) == (14, 8)
assert C3["امتحان"] == 3 and C3["ال"] == 4 and C3["و"] == 1
assert N3 - N2 == 5
# Type-token ratios, as the chapter rounds them.
assert [round(len(c) / n, 2) for n, c in ((N1, C1), (N2, C2), (N3, C3))] == [1.0, 0.89, 0.57]

# Exercise E5: add a fourth message, "imtihanat el-term imta" (the term exams, when?).
FOURTH = "امتحانات الترم امتى"


def counts_with_fourth(policy):
    tokens = [t for message in CORPUS + [FOURTH] for t in policy(message)]
    return len(tokens), Counter(tokens)


assert [(n, len(c)) for n, c in map(counts_with_fourth, (spaces, normalised, clitics_split))] \
    == [(12, 12), (12, 10), (18, 10)]
_, C4 = counts_with_fourth(clitics_split)
assert C4["امتحان"] == 3 and C4["امتحانات"] == 1     # the plural is still its own type
assert counts_with_fourth(normalised)[1]["امتي"] == 3

if __name__ == "__main__":
    for name, (n, c) in (("P1 spaces", (N1, C1)), ("P2 normalised", (N2, C2)),
                         ("P3 clitics split", (N3, C3))):
        print(f"{name:17} N={n:2} V={len(c)}  exam stem={c['امتحان']}")
    print("all policy-count checks passed")
