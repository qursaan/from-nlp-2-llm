"""Chapter 2: context-independent weighted insertion/deletion/substitution.

Costs must be finite and non-negative, with zero cost for equal symbols.
Run: python3 examples/ch03/weighted_edit_distance.py
"""
import math


def weighted_table(source, target, delete, insert, substitute):
    """Return prefix costs; rows consume source, columns consume target."""
    def cost(value):
        if not math.isfinite(value) or value < 0:
            raise ValueError("edit costs must be finite and non-negative")
        return value

    d = [[0.0] * (len(target) + 1) for _ in range(len(source) + 1)]
    for i, x in enumerate(source, 1):
        d[i][0] = d[i - 1][0] + cost(delete(x))
    for j, y in enumerate(target, 1):
        d[0][j] = d[0][j - 1] + cost(insert(y))
    for i, x in enumerate(source, 1):
        for j, y in enumerate(target, 1):
            change = 0.0 if x == y else cost(substitute(x, y))
            d[i][j] = min(d[i - 1][j] + cost(delete(x)),
                          d[i][j - 1] + cost(insert(y)),
                          d[i - 1][j - 1] + change)
    return d


def spelling_change(x, y):
    # An illustrative directed policy, not an estimated error probability.
    return 0.25 if (x, y) == ("ة", "ه") else 1.0


if __name__ == "__main__":
    for a, b in [("مدرسة", "مدرسه"), ("مدرسه", "مدرسة"), ("مدرسة", "مدرسب")]:
        print(a, "->", b, weighted_table(a, b, lambda x: 1, lambda y: 1,
                                         spelling_change)[-1][-1])

# The chapter's step-by-step corner (Example ex:weighted-arabic) and border example.
_one = lambda _: 1.0
_spell = lambda x, y: .25 if (x, y) == ("ة", "ه") else 1.0
_d = weighted_table("مدرسة", "مدرسه", _one, _one, _spell)
assert (_d[4][4], _d[4][5], _d[5][4], _d[5][5]) == (0, 1, 1, .25)
assert weighted_table("مدرسه", "مدرسة", _one, _one, _spell)[-1][-1] == 1
assert [row[0] for row in weighted_table("ال", "", lambda x: 3.0 if x == "ا" else 1.0, _one, _spell)] == [0, 3, 4]
assert round(-math.log(.2), 2) == 1.61                     # a mistake made one time in five
