"""Chapter 3: the numbers in the review questions (quiz, E1, E2, E3, E7).

Run: python3 examples/ch03/review_checks.py
"""
from edit_distance import distance_table

# Quiz 1: split on spaces.
toks = "pay the fee and the late fee today".split()
assert (len(toks), len(set(toks))) == (8, 6)

# Quiz 4: N3-N4 merge three pairs of spellings; types fall, tokens stay.
# Counted from the Lab 3 corpus with the same policy as the lab (N1, N2, Arabic letters).
import re
from pathlib import Path

CORPUS = Path(__file__).resolve().parents[2] / "labs" / "lab03" / "data" / "corpus_ar.txt"
MARKS = re.compile(r"[\u064B-\u0652\u0670\u0640]")
WORD = re.compile(r"[\u0621-\u063A\u0641-\u064A]+")
ALEF = re.compile(r"[\u0622\u0623\u0625\u0671]")


def corpus_tokens(normalize=False):
    out = []
    for line in CORPUS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        line = MARKS.sub("", line)
        if normalize:
            line = ALEF.sub("ا", line).replace("ى", "ي").replace("ة", "ه")
        out += WORD.findall(line)
    return out


raw, merged = corpus_tokens(), corpus_tokens(normalize=True)
assert (len(raw), len(set(raw))) == (185, 105)
assert (len(merged), len(set(merged))) == (185, 102)

# Quiz 7 and 8: unit-cost Levenshtein distances.
assert distance_table("امتحان", "الامتحان")[-1][-1] == 2
assert distance_table("exma", "exam")[-1][-1] == 2

# E1: two token policies for one message.
msg = "والطلاب يسألون عن الطلاب"
spaces = msg.split()
assert (len(spaces), len(set(spaces))) == (4, 4)
split_wa = []
for t in spaces:
    split_wa += ["و", t[1:]] if t.startswith("وال") else [t]
assert split_wa == ["و", "الطلاب", "يسألون", "عن", "الطلاب"]
assert (len(split_wa), len(set(split_wa))) == (5, 4)
assert round(len(set(split_wa)) / len(split_wa), 2) == 0.80

# E2: qalam -> 3ilm, written without vowels.
assert distance_table("قلم", "علم")[-1][-1] == 1

# E3: written Arabic forms and the Latin transliterations, at both substitution costs.
assert distance_table("كاتب", "مكتب")[-1][-1] == 2
assert distance_table("كاتب", "مكتب", sub_cost=2)[-1][-1] == 2
assert distance_table("katib", "maktab")[-1][-1] == 3
assert distance_table("katib", "maktab", sub_cost=2)[-1][-1] == 5

# E7(b): WER is word-level edit distance over the reference length.
ref = "I cannot open the quiz page".split()
hyp = "I can open the quiz page now".split()
assert distance_table(ref, hyp)[-1][-1] == 2
assert round(2 / len(ref), 2) == .33

# Pooled versus averaged WER (the worked case and its comic): pool the edits, then divide.
def wer_counts(pairs):
    """Return (pooled WER, mean of sentence WERs) for (reference, hypothesis) string pairs."""
    edits = [distance_table(r.split(), h.split())[-1][-1] for r, h in pairs]
    words = [len(r.split()) for r, _ in pairs]
    return sum(edits) / sum(words), sum(e / n for e, n in zip(edits, words)) / len(pairs)


pooled, mean = wer_counts([("yes", "no"),
                           ("I want to renew my card before the exam",
                            "I want to renew my car before the exam")])
assert (round(pooled, 2), round(mean, 2)) == (.20, .56)

# Quiz 12: three sentences with (errors, reference words) = (1, 2), (1, 4), (0, 4).
assert 2 / 10 == .20 and round((1 / 2 + 1 / 4 + 0) / 3, 2) == .25

# Worksheet 5, task 8: the Egyptian pair pooled with a one-word reply.
pooled, mean = wer_counts([("انا عايز اجدد الكارنيه بكرة", "عاوز اجدد الكارنيه بكرة الصبح"),
                           ("ايوه", "لا")])
assert (round(pooled, 2), round(mean, 2)) == (.67, .80)

# E8: the length difference is a lower bound, so it filters a lexicon safely.
import random

from fuzzy_search import LEXICON

rng = random.Random(0)
for _ in range(2000):
    a = "".join(rng.choice("abc") for _ in range(rng.randint(0, 6)))
    b = "".join(rng.choice("abc") for _ in range(rng.randint(0, 6)))
    assert distance_table(a, b)[-1][-1] >= abs(len(a) - len(b))
QUERY = "غيب"
keep = [w for w in LEXICON if abs(len(w) - len(QUERY)) <= 1]
assert keep == ["منحه", "جدول", "غياب"]
assert distance_table(QUERY, "محاضره")[-1][-1] == 6      # E8(a): the bound gives only 3
cells = {w: (len(QUERY) + 1) * (len(w) + 1) for w in LEXICON}
saved = sum(c for w, c in cells.items() if w not in keep)
assert (sum(cells[w] for w in keep), saved, sum(cells.values())) == (60, 128, 188)
assert round(saved / 188, 2) == .68

# E9: costs from a confusion table, cost = -ln p(typed | intended taa marbuta).
import math

assert [round(-math.log(p), 2) for p in (.88, .10, .02)] == [.13, 2.30, 3.91]

# Worksheet 5, task 5: constructed Zipf table, and the hapax share of the Lab 3 corpus.
ZIPF = {1: 1200, 2: 610, 3: 390, 4: 300, 5: 245, 10: 118}
assert [r * f for r, f in ZIPF.items()] == [1200, 1220, 1170, 1200, 1225, 1180]
assert (1200 / 20, 1200 / 100) == (60, 12)
assert (round(61 / 105, 2), round(61 / 185, 2)) == (.58, .33)

# Section "Zipf's law and Heaps' law": the constructed Zipf table and its predictions.
assert [r * f for r, f in zip((1, 2, 3, 4), (600, 290, 210, 150))] == [600, 580, 630, 600]
assert 600 / 50 == 12
assert (round(math.log(105 / 36), 3), round(math.log(185 / 51), 3)) == (1.07, 1.289)
assert round(51 ** .831, 1) == 26.2 and round(36 / 51 ** (math.log(105 / 36) / math.log(185 / 51)), 2) == 1.37

print("chapter 3 review numbers: ok")
