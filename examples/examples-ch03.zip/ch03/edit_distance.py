"""Chapter 2: minimum edit distance on Arabic spelling variants and alignment.

Run: python3 examples/ch03/edit_distance.py
"""


def distance_table(source, target, sub_cost=1):
    rows, cols = len(source) + 1, len(target) + 1
    d = [[0] * cols for _ in range(rows)]
    for i in range(rows):
        d[i][0] = i
    for j in range(cols):
        d[0][j] = j
    for i in range(1, rows):
        for j in range(1, cols):
            same = source[i - 1] == target[j - 1]
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1,
                          d[i - 1][j - 1] + (0 if same else sub_cost))
    return d


def align(source, target, sub_cost=1):
    """Backtrace: return (source row, target row, operations) for one best path."""
    d = distance_table(source, target, sub_cost)
    i, j, top, bottom, ops = len(source), len(target), [], [], []
    while i > 0 or j > 0:
        same = i > 0 and j > 0 and source[i - 1] == target[j - 1]
        if i > 0 and j > 0 and d[i][j] == d[i - 1][j - 1] + (0 if same else sub_cost):
            top.append(source[i - 1]); bottom.append(target[j - 1])
            ops.append("M" if same else "S"); i, j = i - 1, j - 1      # DIAG
        elif i > 0 and d[i][j] == d[i - 1][j] + 1:
            top.append(source[i - 1]); bottom.append("*")
            ops.append("D"); i -= 1                                     # DOWN
        else:
            top.append("*"); bottom.append(target[j - 1])
            ops.append("I"); j -= 1                                     # LEFT
    return top[::-1], bottom[::-1], "".join(reversed(ops))


KTB, MAKTABA = "كتب", "مكتبة"
TABLE = distance_table(KTB, MAKTABA)
assert TABLE == [[0, 1, 2, 3, 4, 5],
                 [1, 1, 1, 2, 3, 4],
                 [2, 2, 2, 1, 2, 3],
                 [3, 3, 3, 2, 1, 2]]

PAIRS = {  # (source, target): distance with unit costs
    ("مدرسة", "مدرسه"): 1,              # taa marbuta / haa
    ("إسلام", "اسلام"): 1,              # hamza below
    ("الامتحان", "امتحان"): 2,  # article
    ("قلم", "علم"): 1,                                      # qlm / 'lm (E3)
}
for (a, b), d in PAIRS.items():
    assert distance_table(a, b)[-1][-1] == d
assert distance_table("مدرسة", "مدرسه", sub_cost=2)[-1][-1] == 2

# --- Backtrace and alignment -------------------------------------------------
assert align(KTB, MAKTABA)[2] == "IMMMI"          # insert m, match k t b, insert taa marbuta

TALIM, MALUMAT = "تعليم", "معلومات"   # ta'lim -> ma'lumat
assert distance_table(TALIM, MALUMAT)[-1][-1] == 4
assert distance_table(TALIM, MALUMAT, sub_cost=2)[-1][-1] == 6
assert align(TALIM, MALUMAT)[2] == "SMMSMII"      # t->m, i->u, then insert the plural -at
KATIB, MAKTAB = "كاتب", "مكتب"     # katib -> maktab (exercise E5)
assert align(KATIB, MAKTAB)[2] == "SSMM"                  # cost 2; ties with IMDMM
assert align(KATIB, MAKTAB, sub_cost=2)[2] == "IMDMM"     # cost 2; root letters k t b align
DARS, MADARIS = "درس", "مدارس"    # dars -> madaris (backtrace activity)
assert distance_table(DARS, MADARIS) == [[0, 1, 2, 3, 4, 5], [1, 1, 1, 2, 3, 4],
                                         [2, 2, 2, 2, 2, 3], [3, 3, 3, 3, 3, 2]]
assert align(DARS, MADARIS)[2] == "IMIMM"                 # insert m, match d, insert a, match r s
EXMA, EXAM = "exma", "exam"       # a swapped-letter typo (worked table example)
assert distance_table(EXMA, EXAM) == [[0, 1, 2, 3, 4], [1, 0, 1, 2, 3], [2, 1, 0, 1, 2],
                                      [3, 2, 1, 1, 1], [4, 3, 2, 1, 2]]
assert align(EXMA, EXAM)[2] == "MMSS"                     # last cell: all three moves tie at 2
assert distance_table(EXMA, EXAM, sub_cost=2)[-1][-1] == 2
assert align(EXMA, EXAM, sub_cost=2)[2] == "MMIMD"        # insert a, match m, delete a


def swap_distance(source, target):
    """Levenshtein plus a fourth move: swap two neighbouring letters at cost 1.

    The swap is tried while the table is filled, so a cheaper cell reaches every
    later cell (the optimal-string-alignment form of Damerau-Levenshtein)."""
    d = distance_table("", target) + [[i] + [0] * len(target) for i in range(1, len(source) + 1)]
    for i in range(1, len(source) + 1):
        for j in range(1, len(target) + 1):
            same = source[i - 1] == target[j - 1]
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (0 if same else 1))
            if i > 1 and j > 1 and source[i - 1] == target[j - 2] and source[i - 2] == target[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[-1][-1]


assert swap_distance(EXMA, EXAM) == 1                      # one swap, as a person sees it
assert swap_distance("recieve", "receive") == 1            # a swap inside the word, too
assert swap_distance("مدسرة", "مدرسة") == 1                # Worksheet 5: r and s swapped
assert distance_table("مدسرة", "مدرسة")[-1][-1] == 2

# --- WER is edit distance over words ------------------------------------------
REF = "انا عايز اجدد الكارنيه بكرة".split()        # ana 'ayiz agaddid il-karneh bukra
HYP = "عاوز اجدد الكارنيه بكرة الصبح".split()      # 'awiz agaddid il-karneh bukra is-subh
assert align(REF, HYP)[2] == "DSMMMI"
assert distance_table(REF, HYP)[-1][-1] / len(REF) == 0.60
HYP_NORMALISED = ["عايز" if w == "عاوز" else w for w in HYP]   # dialect variants merged
assert distance_table(REF, HYP_NORMALISED)[-1][-1] / len(REF) == 0.40

if __name__ == "__main__":
    print("     #  " + "  ".join(MAKTABA))
    for label, row in zip("#" + KTB, TABLE):
        print(f"  {label}  " + "  ".join(map(str, row)))
    for (a, b), d in PAIRS.items():
        print(f"{a} -> {b}: {d}")
    for cost in (1, 2):
        top, bottom, ops = align(TALIM, MALUMAT, cost)
        print(f"sub_cost={cost}: {ops}  {' '.join(top)} / {' '.join(bottom)}")
