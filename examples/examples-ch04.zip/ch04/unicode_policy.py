"""Chapter 4: normalization, UTF-8 fragments, offsets, counts, and regex scope.

Run: python3 examples/ch04/unicode_policy.py

Uses only Python's standard library. It is not a grapheme-cluster segmenter.
"""
from collections import Counter
import re
import unicodedata

composed, decomposed = "\u00f1", "n\u0303"
assert len(composed) == 1 and len(decomposed) == 2
assert composed.encode("utf-8") == bytes.fromhex("c3 b1")
assert decomposed.encode("utf-8") == bytes.fromhex("6e cc 83")
assert unicodedata.normalize("NFC", decomposed) == composed
assert unicodedata.normalize("NFC", "\u2460") == "\u2460"
assert unicodedata.normalize("NFKC", "\u2460") == "1"
assert unicodedata.normalize("NFC", "\u0623") != "\u0627"  # no alef stripping

raw = "cafe\u0301 NLP"
normalized = unicodedata.normalize("NFC", raw)
assert raw.index("NLP") == 6 and normalized.index("NLP") == 5
arabic = "\u0639 A"
match = re.search("A", arabic)
assert match.span() == (2, 3)   # code-point offsets
assert len(arabic[:match.start()].encode("utf-8")) == 3  # byte offset

letter_bytes = "\u0639".encode("utf-8")
try:
    letter_bytes[:1].decode("utf-8", errors="strict")
except UnicodeDecodeError:
    pass
else:
    raise AssertionError("an incomplete UTF-8 sequence decoded as a character")
assert (letter_bytes[:1] + letter_bytes[1:]).decode("utf-8") == "\u0639"

sentence = "They picnicked by the pool, then lay back on the grass and looked at the stars."
words = re.findall(r"\w+", sentence)
assert len(words) == 16 and len(set(words)) == 14
assert len(re.findall(r"\w+|[^\w\s]", sentence)) == 18
assert Counter(words)["the"] == 3
assert re.findall(r"[A-Za-z]+", "can't \u0639 3ayez") == ["can", "t", "ayez"]
assert re.findall(r"\b[tT]he\b", "the other The theology") == ["the", "The"]
assert re.search(r"\W[tT]he\W", "the") is None  # consuming delimiters fails at edges
assert re.fullmatch(r"\d+", "\u0661\u0662") is not None
assert re.fullmatch(r"\d+", "\u0661\u0662", re.ASCII) is None
assert re.fullmatch(r".", "\n") is None
assert re.fullmatch(r".", "\n", re.DOTALL) is not None
if __name__ == "__main__":
    print("Unicode database:", unicodedata.unidata_version)
    print("UTF-8, normalization, raw/normalized offsets and token-count checks passed.")
