"""Chapter 4: numbers in the roadmap, the comics, and review items E1, E5-E8.

Run: python3 examples/ch04/review_checks.py
"""
from collections import Counter

from sentence_split import split_sentences

# Roadmap: the running message, split on spaces and stored as UTF-8.
MESSAGE = "When is the exma for CS120?"
assert len(MESSAGE.split()) == 6 and len(MESSAGE) == len(MESSAGE.encode("utf-8")) == 27
assert " ".join(MESSAGE.split()) == MESSAGE          # the space round trip is exact

# Units comic and E5: code points versus UTF-8 bytes.
AYN = "ع"
assert (len(AYN), len(AYN.encode("utf-8"))) == (1, 2)
UNITS = {"امتحان": (6, 12), "مِش": (3, 6), "exam": (4, 4)}  # mish carries a kasra
for word, counts in UNITS.items():
    assert (len(word), len(word.encode("utf-8"))) == counts, word


def merge(pieces, pair):
    out, i = [], 0
    while i < len(pieces):
        if tuple(pieces[i:i + 2]) == pair:
            out.append(pieces[i] + pieces[i + 1])
            i += 2
        else:
            out.append(pieces[i])
            i += 1
    return out


def learn(corpus, steps):
    """The chapter's tie policy: corpus order, first pair that beats the best count."""
    segs = {word: list(word) + ["_"] for word, _ in corpus}
    merges = []
    for _ in range(steps):
        counts = Counter()
        for word, freq in corpus:
            counts.update({pair: freq for pair in zip(segs[word], segs[word][1:])})
        best, best_count = None, 0
        for word, _ in corpus:
            for pair in zip(segs[word], segs[word][1:]):
                if counts[pair] > best_count:
                    best, best_count = pair, counts[pair]
        merges.append((best, best_count))
        segs = {word: merge(s, best) for word, s in segs.items()}
    return merges, segs


def apply(word, merges):
    pieces = list(word) + ["_"]
    for pair, _ in merges:
        pieces = merge(pieces, pair)
    return pieces


# The chapter corpus gives tab:bpe-merges, and lowest -> low est_ (BPE comic).
BOOK = [("low", 5), ("lower", 2), ("newest", 6), ("widest", 3)]
merges, _ = learn(BOOK, 5)
assert [m for m, _ in merges] == [("e", "s"), ("es", "t"), ("est", "_"), ("l", "o"), ("lo", "w")]
assert apply("lowest", merges) == ["low", "est_"]

# E6: a new weighted corpus, three merges, then the unseen word bug.
E6 = [("hug", 10), ("pug", 5), ("pun", 12), ("bun", 4), ("hugs", 5)]
merges, segs = learn(E6, 3)
assert merges == [(("u", "g"), 20), (("u", "n"), 16), (("un", "_"), 16)]
assert segs["pun"] == ["p", "un_"] and segs["hugs"] == ["h", "ug", "s", "_"]
assert apply("bug", merges) == ["b", "ug", "_"]

# E7: predict the listing's sentence counts; (d) is the known failure (true count 2).
E7 = {"سألت أ. منى عن الموعد. لم ترد.": 2,
      "Is the portal down? I can't log in!": 2,
      "The exam is at 10.30 tomorrow.": 1,
      "عايز اغير الجدول الكارنيه ضاع برضه": 1}
for text, n in E7.items():
    assert len(split_sentences(text)) == n, text

# Vocabulary comic and E8: the same IDs under two mappings.
VOCAB_A = ["<unk>", "i", "love", "nlp", "data"]
VOCAB_B = ["<unk>", "data", "i", "love", "nlp"]
IDS = [VOCAB_A.index(w) for w in "i love nlp".split()]
assert IDS == [1, 2, 3] and [VOCAB_B[i] for i in IDS] == ["data", "i", "love"]

if __name__ == "__main__":
    print("Chapter 4 review checks pass.")
