"""Chapter 4: a rule-based sentence splitter for Arabic and English help-desk text.

Run: python3 examples/ch04/sentence_split.py
Every split the chapter reports is asserted here, including the known failures.
"""
import re

BOUNDARY = re.compile(r"(?<=[.!?\u061f])\s+|\n+")  # mark+space or newline
ABBREVIATION = re.compile(       # d. (Dr.), a. (Prof.), m. (Eng.), g.m.
    r"(?:^|\s)(?:\u062f|\u0623|\u0645|Dr|Prof)\.$|\u062c\.\u0645\.?$")

def split_sentences(text):
    sentences, current = [], ""
    for piece in BOUNDARY.split(text):
        current = current + " " + piece if current else piece
        if not ABBREVIATION.search(current):     # a title is not the end of a sentence
            sentences.append(current.strip())
            current = ""
    if current:
        sentences.append(current.strip())
    return [s for s in sentences if s]


# Splits the rules get right.
assert len(split_sentences("عندي مشكلة في التسجيل. الموقع مش بيفتح؟ ساعدوني!")) == 3
assert len(split_sentences("الموعد مع د. أحمد الساعة 10.30 في المكتب.")) == 1
assert len(split_sentences("Dr. Mona moved the exam. Check the portal.")) == 2
assert len(split_sentences("عايز اغير الجدول\nوكمان الكارنيه ضاع")) == 2
assert len(split_sentences("الامتحان يوم الأحد، والنتيجة بعدها بأسبوع؛ صح؟")) == 1

# Known failures, kept visible rather than hidden.
assert len(split_sentences("عايز اغير الجدول الكارنيه ضاع برضه")) == 1        # true: 2
assert len(split_sentences("الرسوم 150 ج.م. ادفعها النهارده")) == 1           # true: 2

if __name__ == "__main__":
    for text in ["عندي مشكلة في التسجيل. الموقع مش بيفتح؟ ساعدوني!",
                 "Dr. Mona moved the exam. Check the portal."]:
        print(split_sentences(text))
