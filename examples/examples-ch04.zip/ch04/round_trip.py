"""The round trip of Section "From IDs back to text": text -> IDs -> text.

Part 1 runs one mixed message through a declared word-level policy and back,
and lists what did not come back. Part 2 (the byte-level case) is asserted on
real GPT-2 tokens in real_tokenizers.py.
Run: python3 examples/ch04/round_trip.py
"""
import re

# The declared policy: lowercase; words and single punctuation marks are
# tokens; a closed vocabulary with <unk>; detokenization joins with spaces
# and removes the space before a question mark (Latin or Arabic).
VOCAB = ["<unk>", "when", "is", "the", "exam", "for", "?", "متى", "الاختبار", "؟"]
ID = {w: i for i, w in enumerate(VOCAB)}


def encode(text):
    tokens = re.findall(r"\w+|[^\w\s]", text.lower())
    return tokens, [ID.get(t, ID["<unk>"]) for t in tokens]


def decode(ids):
    text = " ".join(VOCAB[i] for i in ids)
    return re.sub(r" ([?؟])", r"\1", text)


MESSAGE = "When is the exma for CS120? متى الاختبار؟"
tokens, ids = encode(MESSAGE)
assert tokens == ["when", "is", "the", "exma", "for", "cs120", "?", "متى", "الاختبار", "؟"]
assert ids == [1, 2, 3, 0, 5, 0, 6, 7, 8, 9]
back = decode(ids)
assert back == "when is the <unk> for <unk>? متى الاختبار؟"

# What did not come back, word by word (both texts have eight space-separated words).
lost = [(a, b) for a, b in zip(MESSAGE.split(), back.split()) if a != b]
assert lost == [("When", "when"), ("exma", "<unk>"), ("CS120?", "<unk>?")]
# Lowercasing was a choice; the two <unk> are losses, and one is the course code.
assert sum(i == 0 for i in ids) == 2 and len(ids) == 10

# The Arabic half survived because its three tokens are in the vocabulary.
assert back.endswith("متى الاختبار؟") and MESSAGE.endswith("متى الاختبار؟")

if __name__ == "__main__":
    print(back)
    print("changed:", lost)
