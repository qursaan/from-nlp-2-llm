"""Two real byte-level BPE tokenizers on the same English and Arabic messages.

The chapter's table "Tokens per word and per message" and the round-trip
example print the numbers this file asserts.

    gpt2          GPT-2's English-centred vocabulary (50,256 merge-ranked tokens)
    multilingual  Whisper's multilingual vocabulary (50,257 merge-ranked tokens)

Both vocabularies ship inside the MIT-licensed `openai-whisper` package on PyPI
(whisper/assets/*.tiktoken). They are not copied into this repository. Instead
`real_tokenizers.json` stores, for every message, each token's ID and its bytes
in hex, as measured. Without the vocabularies this script checks the fixture:
every count and ratio, that joined bytes decode to the original text (the round
trip is exact), and which single tokens are not valid UTF-8 on their own.

To measure again (needs `pip install tiktoken`):
    pip download --no-deps --no-binary :all: openai-whisper -d /tmp/w
    tar xzf /tmp/w/openai_whisper-*.tar.gz -C /tmp/w
    python3 examples/ch04/real_tokenizers.py /tmp/w/openai_whisper-*/whisper/assets
Add --write to regenerate the fixture instead of comparing with it.
Run without arguments: python3 examples/ch04/real_tokenizers.py
"""
import base64
import json
import sys
from fractions import Fraction
from pathlib import Path

FIXTURE = Path(__file__).with_name("real_tokenizers.json")
NAMES = ("gpt2", "multilingual")
# GPT-2's pre-tokenization pattern, as used by both vocabularies.
PATTERN = r"""'s|'t|'re|'ve|'m|'ll|'d| ?\p{L}+| ?\p{N}+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""

# Eight help-desk requests, English and Arabic (Egyptian where natural).
PAIRS = [
    ("I want to postpone the exam", "أريد تأجيل الاختبار"),
    ("I want to postpone the submission", "أريد تأجيل التسليم"),
    ("When is the exam?", "متى الاختبار؟"),
    ("I want to renew the ID card tomorrow", "انا عايز اجدد الكارنيه بكرة"),
    ("The students love the library", "الطلاب يحبون المكتبة"),
    ("Where is the lecture hall?", "فين المدرج؟"),
    ("My exam result has a problem", "نتيجة امتحاني فيها مشكلة"),
    ("Please send me the course schedule", "من فضلك ابعتلي جدول المادة"),
]
WORD = "أريد"                      # the round-trip example's word


def measure(assets):
    import tiktoken
    out = {}
    for name in NAMES:
        ranks = {base64.b64decode(tok): int(rank) for tok, rank in
                 (line.split() for line in open(Path(assets) / f"{name}.tiktoken") if line)}
        enc = tiktoken.Encoding(name=name, pat_str=PATTERN, mergeable_ranks=ranks, special_tokens={})
        texts = [t for pair in PAIRS for t in pair] + [WORD]
        out[name] = {t: [[i, enc.decode_single_token_bytes(i).hex()] for i in enc.encode(t)]
                     for t in texts}
    return out


def single_token_decodes(hex_piece):
    try:
        bytes.fromhex(hex_piece).decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def check(data):
    totals = {(n, lang): 0 for n in NAMES for lang in ("en", "ar")}
    words = {"en": 0, "ar": 0}
    for en, ar in PAIRS:
        for lang, text in (("en", en), ("ar", ar)):
            words[lang] += len(text.split())
            for n in NAMES:
                pieces = data[n][text]
                # The round trip: join every token's bytes first, then decode.
                assert b"".join(bytes.fromhex(h) for _, h in pieces).decode("utf-8") == text
                totals[n, lang] += len(pieces)
    assert words == {"en": 46, "ar": 27}
    assert totals == {("gpt2", "en"): 48, ("gpt2", "ar"): 165,
                      ("multilingual", "en"): 50, ("multilingual", "ar"): 93}, totals
    per_word = {k: round(v / words[k[1]], 2) for k, v in totals.items()}
    assert per_word == {("gpt2", "en"): 1.04, ("gpt2", "ar"): 6.11,
                        ("multilingual", "en"): 1.09, ("multilingual", "ar"): 3.44}, per_word
    per_message = {n: round(totals[n, "ar"] / totals[n, "en"], 1) for n in NAMES}
    assert per_message == {"gpt2": 3.4, "multilingual": 1.9}, per_message
    assert Fraction(165, 48) > 3 and Fraction(93, 50) < 2

    # One message in detail: "I want to postpone the exam" and its Arabic.
    ar0 = PAIRS[0][1]
    assert [len(data[n][PAIRS[0][0]]) for n in NAMES] == [6, 7]
    assert [len(data[n][ar0]) for n in NAMES] == [20, 12]

    # GPT-2 splits the first letter of WORD (alef with hamza, U+0623 = D8 A3)
    # into two byte tokens; neither decodes on its own.
    gpt2_word = data["gpt2"][WORD]
    assert [h for _, h in gpt2_word] == ["d8", "a3", "d8b1", "d98a", "d8af"]
    assert [i for i, _ in gpt2_word] == [148, 96, 26897, 22654, 38843]
    assert [single_token_decodes(h) for _, h in gpt2_word] == [False, False, True, True, True]
    assert "".join(bytes.fromhex(h).decode("utf-8", errors="replace")
                   for _, h in gpt2_word) == "��ريد"
    assert len(data["multilingual"][WORD]) == 3
    return totals, per_word, per_message


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--write"]
    if args:
        measured = measure(args[0])
        if "--write" in sys.argv:
            FIXTURE.write_text(json.dumps(measured, ensure_ascii=False, indent=1) + "\n")
        else:
            assert measured == json.loads(FIXTURE.read_text()), "fixture differs from a fresh measurement"
    totals, per_word, per_message = check(json.loads(FIXTURE.read_text()))
    print("tokens per word:", per_word)
    print("Arabic / English tokens per message:", per_message)
