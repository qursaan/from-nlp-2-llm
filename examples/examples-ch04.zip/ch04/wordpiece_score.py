"""WordPiece's merge score on the weighted BPE corpus of Chapter 4 (the BPE merge table, tab:bpe-merges).

Same corpus, symbols (characters plus the end marker _) and tie rule as the BPE
example, so only the score changes:

    BPE        picks the pair with the largest count C(ab);
    WordPiece  picks the pair with the largest C(ab) / (C(a) * C(b)).

Counts are weighted by word frequency. Ties: scan words and pairs in corpus
order and keep the first pair that beats the best score so far. Real WordPiece
(as in BERT) marks continuation pieces with ## and has no end marker; this toy
keeps the BPE example's symbols so the comparison isolates the score.
Run: python3 examples/ch04/wordpiece_score.py
"""
from fractions import Fraction

CORPUS = [("low", 5), ("lower", 2), ("newest", 6), ("widest", 3)]


def counts(segs):
    unit, pair, order = {}, {}, []
    for pieces, freq in segs:
        for u in pieces:
            unit[u] = unit.get(u, 0) + freq
        for p in zip(pieces, pieces[1:]):
            if p not in pair:
                order.append(p)
            pair[p] = pair.get(p, 0) + freq
    return unit, pair, order


def merge(segs, pair):
    out = []
    for pieces, freq in segs:
        new, i = [], 0
        while i < len(pieces):
            if i + 1 < len(pieces) and (pieces[i], pieces[i + 1]) == pair:
                new.append(pieces[i] + pieces[i + 1])
                i += 2
            else:
                new.append(pieces[i])
                i += 1
        out.append((new, freq))
    return out


def best(order, score):
    chosen = None
    for p in order:
        if chosen is None or score[p] > score[chosen]:
            chosen = p
    return chosen


def learn(steps, wordpiece, corpus=CORPUS):
    segs = [(list(w) + ["_"], f) for w, f in corpus]
    history = []
    for _ in range(steps):
        unit, pair, order = counts(segs)
        if wordpiece:
            score = {p: Fraction(pair[p], unit[p[0]] * unit[p[1]]) for p in order}
        else:
            score = dict(pair)
        p = best(order, score)
        history.append((p, pair[p], unit[p[0]], unit[p[1]], score[p]))
        segs = merge(segs, p)
    return history, [" ".join(s) for s, _ in segs]


# BPE reproduces the BPE merge table: e+s, es+t, est+_, l+o, lo+w.
bpe, _ = learn(5, wordpiece=False)
assert [h[0] for h in bpe] == [("e", "s"), ("es", "t"), ("est", "_"), ("l", "o"), ("lo", "w")]

# Under the WordPiece score, BPE's first choice e+s is weak: e occurs 17 times.
unit, pair, _ = counts([(list(w) + ["_"], f) for w, f in CORPUS])
assert (pair[("e", "s")], unit["e"], unit["s"]) == (9, 17, 9)
assert Fraction(9, 17 * 9) == Fraction(1, 17)

wp, segs = learn(3, wordpiece=True)
assert wp == [
    (("i", "d"), 3, 3, 3, Fraction(1, 3)),   # rare, but i and d never occur apart
    (("l", "o"), 7, 7, 7, Fraction(1, 7)),
    (("s", "t"), 9, 9, 9, Fraction(1, 9)),
], wp
assert segs == ["lo w _", "lo w e r _", "n e w e st _", "w id e st _"], segs

if __name__ == "__main__":
        print("WordPiece merges:", ", ".join(f"{a}+{b} ({c}/({x}*{y}) = {s})" for (a, b), c, x, y, s in wp))
