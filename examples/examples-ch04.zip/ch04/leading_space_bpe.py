"""Chapter 4: a word-bounded BPE learner with a leading marker (tab:leading-bpe).

Run: python3 examples/ch04/leading_space_bpe.py

'_' is a toy marker. Every word receives it, including the first word. This does not
preserve arbitrary source whitespace. Ties prefer n+e, then use lexicographic pair order.
"""
from collections import Counter

BASE_ALPHABET = frozenset("abcdefghijklmnopqrstuvwxyz_")


def merge(pieces, pair):
    result, i = [], 0
    while i < len(pieces):
        if tuple(pieces[i:i + 2]) == pair:
            result.append("".join(pair))
            i += 2
        else:
            result.append(pieces[i])
            i += 1
    return result


def learn(words, steps):
    if any("_" in word or not set(word) <= BASE_ALPHABET for word in words):
        raise ValueError("words must use lowercase ASCII letters without the marker")
    corpus = {word: list("_" + word) for word in words}
    history = []
    for _ in range(steps):
        counts = Counter()
        for word, pieces in corpus.items():
            for pair in zip(pieces, pieces[1:]):
                counts[pair] += words[word]
        if not counts:
            break
        pair = min(counts, key=lambda p: (-counts[p], p != ("n", "e"), p))
        history.append((pair, counts[pair]))
        corpus = {word: merge(pieces, pair) for word, pieces in corpus.items()}
    return history, corpus


def encode(word, history):
    if "_" in word or not set(word) <= BASE_ALPHABET:
        raise ValueError("word is outside the declared toy alphabet")
    pieces = list("_" + word)
    for pair, _ in history:
        pieces = merge(pieces, pair)
    return pieces


WORDS = Counter("set new new renew reset renew".split())
HISTORY, CORPUS = learn(WORDS, 4)
assert HISTORY == [(('n', 'e'), 4), (('ne', 'w'), 4), (('_', 'r'), 3), (('_r', 'e'), 3)]
assert CORPUS == {'set': ['_', 's', 'e', 't'], 'new': ['_', 'new'],
                  'renew': ['_re', 'new'], 'reset': ['_re', 's', 'e', 't']}
assert encode("rearrange", HISTORY) == ['_re', 'a', 'r', 'r', 'a', 'n', 'g', 'e']
assert all(encode(word, HISTORY) == pieces for word, pieces in CORPUS.items())
assert learn(Counter(reversed(list(WORDS.elements()))), 4)[0] == HISTORY
assert learn({}, 4) == ([], {})
assert merge(list("aaa"), ('a', 'a')) == ['aa', 'a']  # non-overlapping replacement
assert "".join(encode("new", HISTORY)) == "_new"
VOCABULARY = BASE_ALPHABET | {"".join(pair) for pair, _ in HISTORY}
assert len(VOCABULARY) == 31
assert len({piece for pieces in CORPUS.values() for piece in pieces}) == 6
assert set(encode("rearrange", HISTORY)) <= VOCABULARY
try:
    encode("NEW", HISTORY)
except ValueError:
    pass
else:
    raise AssertionError("text outside the toy alphabet was accepted")
if __name__ == "__main__":
    print(HISTORY)
    print(CORPUS)
    print("rearrange:", encode("rearrange", HISTORY))
